"""
derive_drying_labels.py - label "soak, then scan every ~10 min while it dries" sessions.

Every row of such a session is logged "Saturated", but the wood's SURFACE dries within
20-60 min and the radar mostly sees the surface. So the label for each time step is taken
from the wood-alone scans of that same step: their front-surface echo compared with dry wood
at the same standoff (about 4040 at 50 mm in the 2026-10-22/27 dry data).

    ratio = mean wood-alone front_amplitude of the step / dry-wood amplitude
    ratio >= 1.75          -> Saturated
    1.15 <= ratio < 1.75   -> Damp
    ratio < 1.15           -> "Surface dry" (interior still wet). Not a wetness class, so the
                              wetness model never trains on it (calling it Dry would teach a
                              dangerous answer); the rows still count for the stud model.

The wood + drywall scans that follow the wood-alone scans get the same label.
Writes rows for label_overrides.csv (key = h5_file, or recorded_at when there is no .h5).

Usage: python -m ml.derive_drying_labels --csv PATH/data_log.csv --method soak \
          --dry-wood-amp 4040 --out ml/label_overrides_drying.csv
"""
from __future__ import annotations

import argparse

import pandas as pd

SAT, DAMP = 1.75, 1.15


def derive(csv_path, dry_amp, method_by_sample):
    df = pd.read_csv(csv_path)
    df["ts"] = pd.to_datetime(df["recorded_at"])
    out = []
    for sample, g in df.sort_values("ts").groupby("sample_id"):
        step, prev, steps = -1, None, []
        for _, r in g.iterrows():
            if r["material"] == "Wood" and prev != "Wood":
                step += 1
            steps.append(step)
            prev = r["material"]
        g = g.assign(step=steps)
        t0 = g.loc[g["h5_file"].notna(), "ts"].min()
        for s, gs in g.groupby("step"):
            amp = gs.loc[gs["material"] == "Wood", "front_amplitude"].mean()
            ratio = amp / dry_amp
            if ratio >= SAT:
                label, excl = "Saturated", ""
            elif ratio >= DAMP:
                label, excl = "Damp", ""
            else:
                label, excl = "Surface dry", ""
            for _, r in gs.iterrows():
                out.append({
                    "date": str(r["recorded_at"])[:10],
                    "h5_file": r["h5_file"] if isinstance(r["h5_file"], str) else "",
                    "recorded_at": r["recorded_at"],
                    "wetness": label,
                    "wet_method": method_by_sample.get(sample, "soak"),
                    "sample_id": "",
                    "material": "",
                    "exclude": excl,
                    "minutes_since_first_scan": round((r["ts"] - t0).total_seconds() / 60.0, 1),
                    "note": f"step {s}: wood-alone amplitude {amp:.0f} = {ratio:.2f} x dry",
                })
    return pd.DataFrame(out)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--csv", required=True)
    ap.add_argument("--dry-wood-amp", type=float, default=4040.0)
    ap.add_argument("--method", nargs="*", default=[], help="SAMPLE=METHOD, e.g. S4=soak_2h")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    methods = dict(m.split("=", 1) for m in a.method)
    d = derive(a.csv, a.dry_wood_amp, methods)
    d.to_csv(a.out, index=False)
    print(d.groupby(["wet_method", "wetness"]).size().to_string())


if __name__ == "__main__":
    main()
