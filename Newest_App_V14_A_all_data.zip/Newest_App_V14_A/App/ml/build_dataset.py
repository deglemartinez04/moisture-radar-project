"""
build_dataset.py - turn Data Logging folders into ONE clean table for machine learning.

Why rebuild from the .h5 files instead of copying CSV columns:
  * older CSVs (schema 5) lack the newest features (q*_re/im, norm_rear_*), and
  * every row must be computed by the SAME code the live app uses (features.py +
    close_range.process_frame), otherwise the model sees different numbers live.

What it does
  1. Reads every data_log*.csv given, keeps rows that have an .h5 file.
  2. Re-processes each .h5 with its own *_background.npz and TX-off noise level.
     Rows WITHOUT an .h5 file are skipped, unless --use-csv-features is given: then the
     features the app wrote into the CSV row are used (same code, schema 6 only) and the
     row is marked meta_features_source = csv.
  3. Applies label override files (fixes wrong labels / sample IDs, see those files).
     Key = (date, h5_file), or recorded_at for rows without .h5. An "exclude" column of 1
     keeps the row out of training (quality_ok = 0) but in the table for traceability.
  4. Writes ml_dataset.csv: meta columns, label columns, model feature columns,
     and quality_ok / quality_reason. Columns that must never be model inputs
     (moisture_level, water_amount_ml, time_since_wet_min, trial_number, ...) are only
     kept as meta_* for traceability.

Usage (from the App folder):
  python -m ml.build_dataset --csv "D:/logs/data_log.csv" "D:/logs/data_log_legacy_X.csv" \
      --labels ml/label_overrides.csv --out ml/ml_dataset.csv
(.h5/.npz files are looked up next to each CSV.)
"""
from __future__ import annotations

import argparse
import math
import os
import sys

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))          # App folder

from close_range import process_frame                     # noqa: E402
from features import add_derived, extract_features         # noqa: E402
from ml import h5io                                        # noqa: E402
from ml.feature_set import MODEL_FEATURES, model_row       # noqa: E402

WETNESS_ORDER = {"Dry": 0, "Damp": 1, "Saturated": 2}
STUD_LABEL = {"Drywall": 0, "Wood + drywall": 1}


def features_for_recording(h5_path, background, noise_level, use_filter=True):
    rec = h5io.load(h5_path)
    rf, lb = rec.range_frames, rec.loopback_frames
    corr = np.stack([
        process_frame(rf[k], None if lb is None else lb[k], background,
                      rec.profile, rec.step_length, rec.start_point, use_filter)[1]
        for k in range(rf.shape[0])
    ])
    d = (rec.start_point + np.arange(rf.shape[2]) * rec.step_length) * rec.base_step_length_m
    return corr, d


def load_overrides(paths):
    if isinstance(paths, str):
        paths = [paths]
    out = {}
    for path in paths or []:
        if not path or not os.path.exists(path):
            continue
        ov = pd.read_csv(path, dtype=str).fillna("")
        for _, r in ov.iterrows():
            if r.get("h5_file"):
                out[(r["date"], r["h5_file"])] = r
            if r.get("recorded_at"):
                out[("t", r["recorded_at"])] = r
    return out


def _csv_features(r):
    """Features the app already wrote into a schema-6 CSV row (row has no .h5 file)."""
    if int(r.get("schema_version", 0) or 0) < 6:
        return None
    return add_derived({k: v for k, v in r.items()})


def build(csv_paths, overrides_path, use_filter=True, use_csv_features=False):
    overrides = load_overrides(overrides_path)
    rows = []
    for csv_path in csv_paths:
        folder = os.path.dirname(os.path.abspath(csv_path))
        df = pd.read_csv(csv_path)
        for _, r in df.iterrows():
            h5 = r.get("h5_file")
            h5_path = os.path.join(folder, h5) if isinstance(h5, str) and h5 else None
            if h5_path and os.path.exists(h5_path):
                bg_path = os.path.splitext(h5_path)[0] + "_background.npz"
                background = np.load(bg_path)["background_iq"] if os.path.exists(bg_path) else None
                noise = float(r["noise_floor"]) if str(r.get("noise_source", "")) == "tx_off" else None
                zero = float(r.get("zero_offset_m", 0.0) or 0.0)
                corr, d_raw = features_for_recording(h5_path, background, noise, use_filter)
                d = d_raw - (0.0 if math.isnan(zero) else zero)
                f = add_derived(extract_features(np.abs(corr), np.angle(corr), d,
                                                 background_corrected=background is not None,
                                                 noise_level=noise))
                source, n_frames = "h5", corr.shape[0]
            elif use_csv_features and (f := _csv_features(r)) is not None:
                h5 = ""
                source, n_frames = "csv", np.nan
            else:
                if h5_path:
                    print(f"  missing {h5}, skipped")
                continue
            date = str(r["recorded_at"])[:10]
            label = {
                "material": r["material"],
                "sample_id": str(r["sample_id"]),
                "wetness": str(r["moisture_level"]),
                "wet_method": "none" if r["moisture_level"] == "Dry" else "unknown",
            }
            ov = overrides.get((date, h5)) if h5 else None
            if ov is None:
                ov = overrides.get(("t", str(r["recorded_at"])))
            excluded = False
            if ov is not None:
                for k in ("wetness", "wet_method", "sample_id", "material"):
                    if ov.get(k):
                        label[k] = ov[k]
                excluded = str(ov.get("exclude", "")).strip() in ("1", "true", "True", "yes")
            out = {
                "meta_source_csv": os.path.basename(csv_path),
                "meta_h5_file": h5,
                "meta_recorded_at": r["recorded_at"],
                "meta_date": date,
                "meta_background_id": r.get("background_id", ""),
                "meta_logged_moisture_level": r["moisture_level"],
                "meta_water_amount_ml": r.get("water_amount_ml"),
                "meta_sensor_temperature_c": r.get("sensor_temperature_c"),
                "meta_num_frames": n_frames,
                "meta_features_source": source,
                "meta_override_note": "" if ov is None else ov.get("note", ""),
                "meta_excluded": int(excluded),
                "standoff_mm": float(r["measured_distance_mm"]),
                "material": label["material"],
                "sample_id": label["sample_id"],
                "wet_method": label["wet_method"],
                "wetness": label["wetness"],
                "wetness_ordinal": WETNESS_ORDER.get(label["wetness"], np.nan),
                "has_stud": STUD_LABEL.get(label["material"], np.nan),
            }
            out.update(model_row(f))
            rows.append(out)
    data = pd.DataFrame(rows)
    data["meta_recorded_at"] = pd.to_datetime(data["meta_recorded_at"])
    # minutes since the first wet scan of the same (date, sample) session; drying clock
    wet = data["wetness"] != "Dry"
    first = data[wet].groupby(["meta_date", "sample_id"])["meta_recorded_at"].transform("min")
    data["meta_minutes_since_first_wet_scan"] = np.nan
    data.loc[wet, "meta_minutes_since_first_wet_scan"] = (
        (data.loc[wet, "meta_recorded_at"] - first).dt.total_seconds() / 60.0).round(1)
    # cross-validation groups: one block = one condition at one standoff on one day
    data["cv_group"] = (data["meta_date"] + "|" + data["sample_id"] + "|" + data["material"] + "|"
                        + data["wetness"] + "|" + data["standoff_mm"].astype(int).astype(str))
    _quality(data)
    return data


def _quality(data):
    data.drop(columns=[c for c in ("quality_reason", "quality_ok") if c in data], inplace=True)
    reasons = []
    feat_ok = data[MODEL_FEATURES].notna().all(axis=1)
    excl = data.get("meta_excluded", pd.Series(0, index=data.index)).fillna(0).astype(int) == 1
    med = data.groupby(["meta_date", "material", "standoff_mm"])["front_distance_m"].transform("median")
    jump = (data["front_distance_m"] - med).abs() > 0.015
    for i in data.index:
        r = []
        if not feat_ok[i]:
            r.append("missing features (wall/rear window not found)")
        if jump[i]:
            r.append("front surface >15 mm from the median of its group (mis-detected)")
        if excl[i]:
            r.append("excluded by label override")
        reasons.append("; ".join(r))
    data["quality_reason"] = reasons
    data["quality_ok"] = (data["quality_reason"] == "").astype(int)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--csv", nargs="+", required=True)
    ap.add_argument("--labels", nargs="+", default=[os.path.join(HERE, "label_overrides.csv")])
    ap.add_argument("--use-csv-features", action="store_true",
                    help="also use rows without an .h5 file, with the features stored in the CSV")
    ap.add_argument("--out", default=os.path.join(HERE, "ml_dataset.csv"))
    ap.add_argument("--no-filter", action="store_true", help="match recordings made with the distance filter off")
    a = ap.parse_args()
    data = build(a.csv, a.labels, use_filter=not a.no_filter, use_csv_features=a.use_csv_features)
    data.to_csv(a.out, index=False)
    print(f"wrote {a.out}: {len(data)} rows, {int(data.quality_ok.sum())} pass quality")
    print(data.groupby(["material", "wetness"]).size().to_string())


if __name__ == "__main__":
    main()
