"""
make_v14_datasets.py - the two cleaned training tables behind the two V14 apps.

  dataset_A_all_useful.csv   every usable recording:
        2026-10-22 dry (all standoffs), 2026-10-27 dry + wet (labels fixed by
        label_overrides.csv), 2026-10-29 / 10-31 drying series (labels from
        label_overrides_drying.csv), incl. the 6 S4 rows without .h5 (CSV features).
  dataset_B_dry_plus_new.csv  same, but WITHOUT the older wet trials (2026-10-27 pour/soak):
        only the old DRY scans + the new drying series.

Input = the full table from build_dataset.py (all CSVs, both override files,
--use-csv-features). Quality flags are recomputed for each table.

Usage: python -m ml.make_v14_datasets --full v14_full.csv --outdir ml
"""
from __future__ import annotations

import argparse
import os

import pandas as pd

from ml.build_dataset import _quality

NEW_SESSION_START = "2026-10-29"
DROP_ALWAYS = {"Open air (no target)"}


def make(full):
    full = full[~full["material"].isin(DROP_ALWAYS)].copy()
    full["meta_recorded_at"] = pd.to_datetime(full["meta_recorded_at"])
    a = full.copy()
    old_wet = (full["meta_date"] < NEW_SESSION_START) & (full["wetness"] != "Dry")
    b = full[~old_wet].copy()
    for d in (a, b):
        _quality(d)
    return a.reset_index(drop=True), b.reset_index(drop=True)


def summary(name, d):
    ok = d[d["quality_ok"] == 1]
    t = ok.groupby(["material", "wetness", "standoff_mm"]).size().unstack(fill_value=0)
    return f"{name}: {len(d)} rows, {len(ok)} pass quality\n{t.to_string()}\n"


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--full", required=True)
    ap.add_argument("--outdir", default=os.path.dirname(os.path.abspath(__file__)))
    x = ap.parse_args()
    a, b = make(pd.read_csv(x.full))
    a.to_csv(os.path.join(x.outdir, "dataset_A_all_useful.csv"), index=False)
    b.to_csv(os.path.join(x.outdir, "dataset_B_dry_plus_new.csv"), index=False)
    print(summary("A", a))
    print(summary("B", b))


if __name__ == "__main__":
    main()
