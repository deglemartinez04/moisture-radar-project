# Machine learning workflow (v11)

```
Data Logging folders (data_log*.csv + .h5 + *_background.npz)
        │  python -m ml.build_dataset --csv <csv files>      (re-extracts features from the .h5 files)
        ▼
ml/ml_dataset.csv  (one clean row per recording: meta_*, labels, 28 model features, quality_ok)
        │  python -m ml.train_model                          (needs scikit-learn on the training PC)
        ▼
App/models/stud_model.json, wetness_model.json, training_report.txt
        │  copied with the app; loaded by moisture_model.py (numpy only)
        ▼
Moisture Level tab: Dry / Damp / Saturated + confidence + wetness index + stud probability
```

## 1. Build the dataset
Run from the `App` folder:
```
python -m ml.build_dataset --csv "PATH/data_log_legacy_20261027_124319.csv" "PATH/data_log.csv" --out ml/ml_dataset.csv
```
- Each row is recomputed from its .h5 with its own background and noise level, by the
  same `close_range.process_frame` + `features.extract_features` code the live view uses.
- `ml/label_overrides.csv` fixes labels per (date, h5_file). It currently swaps the
  2026-10-27 wet runs: logged "Saturated" (poured 160 mL) -> **Damp**, logged "Damp"
  (soaked 2 x 10 min, sample S2) -> **Saturated**. Add a line there for any future mistake
  instead of editing the CSV.
- Never used as model inputs: moisture_level, water_amount_ml, time_since_wet_min,
  trial_number, sample_id, standoff, temperatures, background_id (kept as `meta_*`).
- `quality_ok = 0` rows (wall not found, front surface mis-detected) are excluded from
  training; `quality_reason` says why.

## 2. Train
```
pip install scikit-learn pandas
python -m ml.train_model --data ml/ml_dataset.csv --out models
```
Options: `--include-wood-only` (also learn from bare-wood rows), `--shape-only` (drop the
two standoff-dependent features). Read `models/training_report.txt`:
- grouped CV = all placements of one condition/standoff/day are held out together;
- leave-one-standoff-out = accuracy at a distance the model never saw;
- day-shift check = whether the model can tell recording days apart (should be ~0.5).

## 3. Use in the app
Copy `models/` next to `main.py` (it is already in the zip). Restart the app. The Moisture
Level tab title changes to "Live Prediction (trained model)". Retrain whenever new data
is added and copy the new JSON files; no code changes are needed.

## Limits of the first model (2026-10-28 data)
- Only one wet session per class, and the Saturated rows are all sample S2 while Damp is
  S1: the model may partly have learned the board or the session, not only the water.
- Wet wood dried during the 1-2 h of scanning, so labels get less true over time
  (`meta_minutes_since_first_wet_scan` records this).
- Flush (12 mm) is unreliable; 40-60 mm from the PCB works best.
- The outputs are classes and a wetness index (0 = dry, 100 = saturated), NOT %MC.
  For %MC, label future recordings with the weighed moisture content and switch the
  wetness model to regression.

---------------------------------------------------------------------------------
## V14: two model variants (same app code, different training data)

| | V14-A "all useful data" | V14-B "old dry + new wet only" |
|---|---|---|
| Dry scans | 2026-10-22 + 2026-10-27, all standoffs | same |
| Older wet trials (2026-10-27 pour / soak) | **used** (labels fixed by label_overrides.csv) | **left out** |
| New drying series (S4 2026-10-29, S3 2026-10-31) | used | used |
| Wetness model trained on | Wood + drywall, 40/50/60 mm, 60 rows | Wood + drywall, 50 mm only, 23 rows |
| Stud model trained on | all standoffs, 126 rows | all standoffs, 89 rows |
| Training table | ml/dataset_A_all_useful.csv | ml/dataset_B_dry_plus_new.csv |

The model in App/models/ decides which variant the app is; the Live tab title shows it.

### Cleaning applied to data_log.csv of datalogV13 (-> ml/data_log_V13_clean.csv)
* Every row was logged "Saturated", but the board dries while it is scanned. Each ~20-min
  step was relabelled from its own wood-alone scans (ml/derive_drying_labels.py): front
  echo / dry-wood echo at 50 mm (4040) >= 1.75 Saturated, 1.15-1.75 Damp, < 1.15
  "Surface dry". The wood + drywall scans of the same step get the same label.
* "Surface dry" (interior still wet, surface already back to the dry level) is NOT
  trained as Dry - that would teach the device to call a wet stud dry. Those rows are only
  used by the stud model.
* Rows 2-7 (S4 first t=0, no .h5): kept, features taken from the CSV (checked: CSV features
  equal the .h5 rebuild to 4 decimals). Marked meta_features_source = csv.
* Wood + drywall rows whose front surface was detected at 65-82 mm instead of ~50 mm
  (drywall echo lost behind the wet stud echo) are excluded by the quality check (8 rows, S4).
* Open-air row and model-irrelevant columns (water amount, time since wet, trial number,
  temperatures) are never model inputs; they stay only as meta_* columns.

### Rebuild
    python -m ml.derive_drying_labels --csv <datalogV13>/data_log.csv --method S4=soak_2h S3=soak_1h --out ml/label_overrides_drying.csv
    python -m ml.build_dataset --csv <v9+10>/data_log_legacy_20261027_124319.csv <v9+10>/data_log.csv <datalogV13>/data_log.csv \
        --labels ml/label_overrides.csv ml/label_overrides_drying.csv --use-csv-features --out v14_full.csv
    python -m ml.make_v14_datasets --full v14_full.csv --outdir ml
    python -m ml.train_model --data ml/dataset_A_all_useful.csv --out models --wet-standoffs 40 50 60 --title "V14-A (all useful data)"
    python -m ml.train_model --data ml/dataset_B_dry_plus_new.csv --out models --wet-standoffs 50 --max-C 1 --title "V14-B (old dry + new wet only)"
