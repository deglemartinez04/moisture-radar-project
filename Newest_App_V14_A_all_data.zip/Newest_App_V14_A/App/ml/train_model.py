"""
train_model.py - train and evaluate the stud and wetness models from ml_dataset.csv.

Two small models (the dataset is small, so simple + regularised beats complex):
  stud     : Drywall alone (0) vs Wood + drywall (1)
  wetness  : Dry / Damp / Saturated, trained on Wood + drywall rows (the real-wall case;
             add --include-wood-only to also use bare-wood rows)

Model: standardise -> L2 logistic regression. It is exported to models/*.json (means,
scales, coefficients) so the app needs only numpy to run it, no scikit-learn/pickle
version issues on the Raspberry Pi. A random forest is evaluated for comparison only.

Evaluation (honest, not optimistic):
  * Grouped 5-fold CV: all placements of one condition at one standoff on one day stay
    in the same fold (neighbouring placements are near-duplicates).
  * Leave-one-standoff-out: train on the other distances, test on the unseen one.
  * Day-shift check: how well can a model tell the two DRY days apart? If it can, day /
    session effects are large and wet-vs-dry accuracy may partly be learning the session.

Usage (from the App folder; needs scikit-learn on the training PC: pip install scikit-learn):
  python -m ml.train_model --data ml/ml_dataset.csv --out models
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import sys

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score, confusion_matrix
from sklearn.model_selection import GroupKFold, LeaveOneGroupOut
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from ml.feature_set import MODEL_FEATURES, SHAPE_FEATURES  # noqa: E402

WET_CLASSES = ["Dry", "Damp", "Saturated"]


def lr(C):
    # balanced: every class counts equally even when e.g. wet rows outnumber dry rows 4:1
    return make_pipeline(StandardScaler(), LogisticRegression(C=C, max_iter=5000, class_weight="balanced"))


def rf():
    return RandomForestClassifier(n_estimators=300, min_samples_leaf=2, random_state=0,
                                  class_weight="balanced")


def cv_predict(make, X, y, groups, splitter):
    pred = np.empty_like(y)
    for tr, te in splitter.split(X, y, groups):
        if len(np.unique(y[tr])) < 2:
            pred[te] = y[tr][0]
            continue
        m = make().fit(X[tr], y[tr])
        pred[te] = m.predict(X[te])
    return pred


def report_block(name, y, pred, labels):
    cm = confusion_matrix(y, pred, labels=labels)
    lines = [f"{name}: accuracy {np.mean(pred == y):.2f}, balanced accuracy {balanced_accuracy_score(y, pred):.2f}",
             "  confusion (rows = true, cols = predicted): " + " / ".join(map(str, labels))]
    for lab, row in zip(labels, cm):
        lines.append(f"    {lab:>14}: {row.tolist()}")
    return lines


C_GRID = (0.1, 0.3, 1.0, 3.0, 10.0)


def evaluate(task, df, y, features, labels, out):
    X = df[features].to_numpy(float)
    groups = df["cv_group"].to_numpy()
    standoff = df["standoff_mm"].to_numpy()
    n_folds = min(5, len(np.unique(groups)))
    out.append(f"\n=== {task}: {len(y)} rows, {len(np.unique(groups))} condition blocks, "
               f"{len(features)} features ===")
    out.append("  class counts: " + ", ".join(f"{c}={int((y == c).sum())}" for c in labels))
    best = None
    for C in C_GRID:
        p = cv_predict(lambda: lr(C), X, y, groups, GroupKFold(n_folds))
        ba = balanced_accuracy_score(y, p)
        out.append(f"  logistic C={C:<5} grouped-CV balanced accuracy {ba:.2f}")
        if best is None or ba > best[0]:
            best = (ba, C, p)
    out += ["  " + s for s in report_block(f"logistic C={best[1]} (grouped CV)", y, best[2], labels)]
    p_rf = cv_predict(rf, X, y, groups, GroupKFold(n_folds))
    out.append(f"  random forest grouped-CV balanced accuracy {balanced_accuracy_score(y, p_rf):.2f} (comparison only)")
    if len(np.unique(standoff)) > 1:
        p_lso = cv_predict(lambda: lr(best[1]), X, y, standoff, LeaveOneGroupOut())
        out += ["  " + s for s in report_block("logistic, leave-one-STANDOFF-out", y, p_lso, labels)]
        for s in sorted(np.unique(standoff)):
            m = standoff == s
            out.append(f"    unseen standoff {s:>4.0f} mm: accuracy {np.mean(p_lso[m] == y[m]):.2f} (n={m.sum()})")
    # leave-one-DAY-out: every recording day is a different session / board / setup
    days = df["meta_date"].to_numpy()
    if len(np.unique(days)) > 2:
        p_day = cv_predict(lambda: lr(best[1]), X, y, days, LeaveOneGroupOut())
        out += ["  " + s for s in report_block("logistic, leave-one-DAY-out", y, p_day, labels)]
        for d in sorted(np.unique(days)):
            m = days == d
            cls = ", ".join(f"{c}={int((y[m] == c).sum())}" for c in labels if (y[m] == c).any())
            out.append(f"    unseen day {d}: accuracy {np.mean(p_day[m] == y[m]):.2f} ({cls})")
    return best[1]


def export(model_pipe, features, classes, task, meta, path):
    scaler, clf = model_pipe.named_steps["standardscaler"], model_pipe.named_steps["logisticregression"]
    coef = clf.coef_
    intercept = clf.intercept_
    if coef.shape[0] == 1:          # binary -> two rows so the runtime is always softmax
        coef = np.vstack([-coef[0] / 2, coef[0] / 2])
        intercept = np.array([-intercept[0] / 2, intercept[0] / 2])
    model = {
        "task": task,
        "type": "standardized_logistic_regression",
        "features": features,
        "classes": [str(c) for c in clf.classes_],
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "coef": coef.tolist(),
        "intercept": intercept.tolist(),
        "trained_at": dt.datetime.now().isoformat(timespec="seconds"),
        **meta,
    }
    with open(path, "w") as f:
        json.dump(model, f, indent=1)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", default=os.path.join(HERE, "ml_dataset.csv"))
    ap.add_argument("--out", default=os.path.join(os.path.dirname(HERE), "models"))
    ap.add_argument("--include-wood-only", action="store_true")
    ap.add_argument("--wet-standoffs", type=float, nargs="*", default=None,
                    help="train the wetness model only on these standoffs (mm), e.g. 50")
    ap.add_argument("--stud-standoffs", type=float, nargs="*", default=None,
                    help="train the stud model only on these standoffs (mm)")
    ap.add_argument("--max-C", type=float, default=None,
                    help="cap the regularisation search (small datasets: 1.0 avoids over-fitting)")
    ap.add_argument("--title", default="", help="name written at the top of the report / into the JSON")
    ap.add_argument("--shape-only", action="store_true",
                    help="drop front_distance/front_amplitude (more standoff-robust, less information)")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    global C_GRID
    if a.max_C:
        C_GRID = tuple(c for c in C_GRID if c <= a.max_C)
    data = pd.read_csv(a.data)
    data = data[data["quality_ok"] == 1].copy()
    features = SHAPE_FEATURES if a.shape_only else MODEL_FEATURES
    out = [f"Training report {a.title} {dt.datetime.now():%Y-%m-%d %H:%M}  ({len(data)} rows pass quality)",
           f"features: {'shape-only' if a.shape_only else 'shape + level'}"]

    # ---- stud model ----
    stud = data[data["has_stud"].isin([0, 1])].copy()
    if a.stud_standoffs:
        stud = stud[stud["standoff_mm"].isin(a.stud_standoffs)]
    ys = np.where(stud["has_stud"] == 1, "Stud", "No stud").astype(object)
    C = evaluate("STUD (Drywall vs Wood + drywall)", stud, ys, features, ["No stud", "Stud"], out)
    m = lr(C).fit(stud[features].to_numpy(float), ys)
    export(m, features, ["No stud", "Stud"], "stud", {"C": C, "n_rows": int(len(ys)), "dataset": a.title,
            "standoffs_mm": sorted(stud["standoff_mm"].unique().tolist())},
           os.path.join(a.out, "stud_model.json"))

    # ---- wetness model ----
    mats = ["Wood + drywall"] + (["Wood"] if a.include_wood_only else [])
    wet = data[data["material"].isin(mats) & data["wetness"].isin(WET_CLASSES)].copy()
    if a.wet_standoffs:
        wet = wet[wet["standoff_mm"].isin(a.wet_standoffs)]
    yw = wet["wetness"].to_numpy(object)
    C = evaluate(f"WETNESS on {', '.join(mats)}", wet, yw, features, WET_CLASSES, out)
    m = lr(C).fit(wet[features].to_numpy(float), yw)
    export(m, features, WET_CLASSES, "wetness", {"C": C, "n_rows": int(len(yw)), "materials": mats,
            "dataset": a.title, "standoffs_mm": sorted(wet["standoff_mm"].unique().tolist())},
           os.path.join(a.out, "wetness_model.json"))

    # binary view (what matters first: is the stud wet at all?)
    yb = np.where(yw == "Dry", "Dry", "Wet").astype(object)
    evaluate("WET vs DRY (binary view of the same rows)", wet, yb, features, ["Dry", "Wet"], out)

    # ---- day-shift check on DRY rows ----
    dry = wet[wet["wetness"] == "Dry"]
    if dry["meta_date"].nunique() >= 2 and dry.groupby("meta_date")["cv_group"].nunique().min() >= 2:
        yd = dry["meta_date"].to_numpy(object)
        p = cv_predict(lambda: lr(0.3), dry[features].to_numpy(float), yd, dry["cv_group"].to_numpy(),
                       GroupKFold(min(5, dry["cv_group"].nunique())))
        out.append(f"\n=== DAY-SHIFT CHECK (dry rows only, can the model tell the recording DAY?) ===\n"
                   f"  balanced accuracy {balanced_accuracy_score(yd, p):.2f} (0.5 = no day effect; "
                   f"near 1.0 = strong session effect, treat wet-vs-dry accuracy with caution)")

    # top coefficients of the wetness model
    clf = m.named_steps["logisticregression"]
    out.append("\n=== WETNESS model: strongest standardized coefficients ===")
    for ci, cls in enumerate(clf.classes_):
        order = np.argsort(-np.abs(clf.coef_[ci]))[:6]
        out.append(f"  {cls}: " + ", ".join(f"{features[j]} {clf.coef_[ci][j]:+.2f}" for j in order))

    text = "\n".join(out)
    print(text)
    with open(os.path.join(a.out, "training_report.txt"), "w") as f:
        f.write(text + "\n")


if __name__ == "__main__":
    main()
