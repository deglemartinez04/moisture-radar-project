# Machine learning workflow (v11)

```
Data Logging folders (data_log*.csv + .h5 + *_background.npz)
        │  python -m ml.build_dataset --csv <csv files>      (re-extracts features from the .h5 files)
        ▼
ml/ml_dataset.csv  (one clean row per recording: meta_*, labels, 28 model features, quality_ok)
        │  python -m ml.train_model                          (needs scikit-learn on the training PC)
        ▼
App/models/stud_model.json, wetness_model.json, training_report.txt
        │  copied with the app; loaded by moisture_model.py (numpy only)
        ▼
Moisture Level tab: Dry / Damp / Saturated + confidence + wetness index + stud probability
```

## 1. Build the dataset
Run from the `App` folder:
```
python -m ml.build_dataset --csv "PATH/data_log_legacy_20261027_124319.csv" "PATH/data_log.csv" --out ml/ml_dataset.csv
```
- Each row is recomputed from its .h5 with its own background and noise level, by the
  same `close_range.process_frame` + `features.extract_features` code the live view uses.
- `ml/label_overrides.csv` fixes labels per (date, h5_file). It currently swaps the
  2026-10-27 wet runs: logged "Saturated" (poured 160 mL) -> **Damp**, logged "Damp"
  (soaked 2 x 10 min, sample S2) -> **Saturated**. Add a line there for any future mistake
  instead of editing the CSV.
- Never used as model inputs: moisture_level, water_amount_ml, time_since_wet_min,
  trial_number, sample_id, standoff, temperatures, background_id (kept as `meta_*`).
- `quality_ok = 0` rows (wall not found, front surface mis-detected) are excluded from
  training; `quality_reason` says why.

## 2. Train
```
pip install scikit-learn pandas
python -m ml.train_model --data ml/ml_dataset.csv --out models
```
Options: `--include-wood-only` (also learn from bare-wood rows), `--shape-only` (drop the
two standoff-dependent features). Read `models/training_report.txt`:
- grouped CV = all placements of one condition/standoff/day are held out together;
- leave-one-standoff-out = accuracy at a distance the model never saw;
- day-shift check = whether the model can tell recording days apart (should be ~0.5).

## 3. Use in the app
Copy `models/` next to `main.py` (it is already in the zip). Restart the app. The Moisture
Level tab title changes to "Live Prediction (trained model)". Retrain whenever new data
is added and copy the new JSON files; no code changes are needed.

## Limits of the first model (2026-10-28 data)
- Only one wet session per class, and the Saturated rows are all sample S2 while Damp is
  S1: the model may partly have learned the board or the session, not only the water.
- Wet wood dried during the 1-2 h of scanning, so labels get less true over time
  (`meta_minutes_since_first_wet_scan` records this).
- Flush (12 mm) is unreliable; 40-60 mm from the PCB works best.
- The outputs are classes and a wetness index (0 = dry, 100 = saturated), NOT %MC.
  For %MC, label future recordings with the weighed moisture content and switch the
  wetness model to regression.
