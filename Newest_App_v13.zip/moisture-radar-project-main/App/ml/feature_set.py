"""
feature_set.py - the ONE list of model inputs, shared by build_dataset.py,
train_model.py and the live predictor (moisture_model.py).

Never inputs: moisture_level, water_amount_ml, time_since_wet_min, trial_number,
sample_id, standoff_mm, recorded_at, background_id, temperatures (labels / conditions).
"""
from __future__ import annotations

import math

NORM_Q = [f"q{o}_{c}" for o in (10, 15, 20, 25, 30, 35, 40, 45, 50) for c in ("re", "im")]

# Standoff-robust shape features (front-normalized complex profile + rear window).
SHAPE_FEATURES = NORM_Q + [
    "norm_rear_mag_db", "norm_rear_phase_sin", "norm_rear_phase_cos",
    "rear_energy_ratio_db", "rear_centroid_offset_m", "rear_peak_offset_m",
    "rear_phase_sin", "rear_phase_cos",
]
# Level features: depend on standoff and gain, but with a fixed case standoff they carry
# real information (wet wood reflects more strongly).
LEVEL_FEATURES = ["front_distance_m", "front_amplitude_db"]

MODEL_FEATURES = SHAPE_FEATURES + LEVEL_FEATURES


def _f(v):
    try:
        v = float(v)
    except (TypeError, ValueError):
        return float("nan")
    return v


def model_row(features: dict) -> dict:
    """Pick/derive MODEL_FEATURES from features.extract_features() (+ add_derived())."""
    out = {k: _f(features.get(k)) for k in MODEL_FEATURES if k != "front_amplitude_db"}
    amp = _f(features.get("front_amplitude"))
    out["front_amplitude_db"] = 20.0 * math.log10(amp) if amp and amp > 0 else float("nan")
    for k in ("rear_phase_sin", "rear_phase_cos", "norm_rear_phase_sin", "norm_rear_phase_cos"):
        if math.isnan(out.get(k, float("nan"))):
            base = "rear_phase_rad" if k.startswith("rear") else "norm_rear_phase_rad"
            ph = _f(features.get(base))
            if not math.isnan(ph):
                out[k] = math.sin(ph) if k.endswith("sin") else math.cos(ph)
    return out
