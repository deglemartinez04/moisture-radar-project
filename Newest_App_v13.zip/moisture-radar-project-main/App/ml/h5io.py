"""
h5io.py - read an app recording (.h5 written by acconeer H5Recorder) into numpy.

Returns the range subframes (frames, sweeps, points), the loopback subframes
(frames, sweeps, 1) or None, and the range-subsweep geometry. Uses h5py when installed
(it is, with acconeer-exptool); otherwise a small built-in reader (h5_fallback.py).
"""
from __future__ import annotations

import json
from dataclasses import dataclass

import numpy as np


@dataclass
class Recording:
    range_frames: np.ndarray        # complex (frames, sweeps, points)
    loopback_frames: np.ndarray | None
    start_point: int
    step_length: int
    profile: int
    base_step_length_m: float


def _profile_int(p):
    return int(str(p).split("_")[-1]) if not isinstance(p, int) else p


def _from_parts(z, cfg, meta) -> Recording:
    sensor = next(iter(cfg["groups"][0].values()))
    subs = sensor["subsweeps"]
    has_lb = len(subs) >= 2 and bool(subs[0].get("enable_loopback", False))
    rng = subs[1] if has_lb else subs[0]
    n_lb = int(subs[0]["num_points"]) if has_lb else 0
    return Recording(
        range_frames=z[:, :, n_lb:],
        loopback_frames=z[:, :, :n_lb] if has_lb else None,
        start_point=int(rng["start_point"]),
        step_length=int(rng["step_length"]),
        profile=_profile_int(rng["profile"]),
        base_step_length_m=float(meta.get("base_step_length_m", 0.00250227400101721)),
    )


def load(path: str) -> Recording:
    try:
        import h5py
    except ImportError:
        from ml import h5_fallback
        z, cfg, meta = h5_fallback.read_frames(path)
        return _from_parts(z, cfg, meta)

    def _txt(v):
        return v.decode() if isinstance(v, bytes) else str(v)

    with h5py.File(path, "r") as f:
        entry = f["sessions/session_0/group_0/entry_0"]
        fr = entry["result/frame"][()]
        cfg = json.loads(_txt(f["sessions/session_0/session_config"][()]))
        meta = json.loads(_txt(entry["metadata"][()]))
    z = fr["real"].astype(np.float64) + 1j * fr["imag"].astype(np.float64)
    return _from_parts(z, cfg, meta)
