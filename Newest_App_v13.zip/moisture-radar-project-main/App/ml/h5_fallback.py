"""Fallback used only when h5py is not installed.
Minimal reader for exptool A121 .h5 'frame' datasets without h5py.

Parses HDF5 v1 B-tree (TREE, type 1) chunk indexes, keeps the 3-D dataset whose chunks
decompress to int16-complex data, assembles (frames, sweeps, points) complex array.
Also extracts the session_config / metadata JSON strings and the 1-D temperature data.
"""
import json, re, struct, zlib
import numpy as np


def _chunk_entries(b):
    """Yield (rank_plus_one, size, offsets, addr) for every leaf entry of every type-1 B-tree."""
    for m in re.finditer(rb'TREE\x01\x00', b):          # type 1 (raw data chunks), level 0
        i = m.start()
        n = struct.unpack_from('<H', b, i + 6)[0]
        p = i + 8 + 16                                     # skip left/right siblings
        # rank unknown: try rank+1 in 2..5 and keep the one that gives sane addresses
        for r1 in (4, 2, 3, 5):
            ksz = 8 + 8 * r1
            ok, ents, q = True, [], p
            for _ in range(n):
                size, mask = struct.unpack_from('<II', b, q)
                offs = struct.unpack_from('<' + 'Q' * r1, b, q + 8)
                addr = struct.unpack_from('<Q', b, q + ksz)[0]
                if addr >= len(b) or size == 0 or size > len(b) or offs[-1] != 0:
                    ok = False
                    break
                ents.append((r1, size, offs[:-1], addr))
                q += ksz + 8
            if ok and ents:
                yield from ents
                break


def read_frames(path):
    b = open(path, 'rb').read()
    cfg = session_config(b)
    sensor = cfg['groups'][0]['1']
    spf = sensor['sweeps_per_frame']
    npts = sum(s['num_points'] for s in sensor['subsweeps'])
    chunks = {}
    for r1, size, offs, addr in _chunk_entries(b):
        if r1 != 4:
            continue
        try:
            raw = zlib.decompress(b[addr:addr + size])
        except zlib.error:
            continue
        chunks[offs] = raw
    if not chunks:
        raise ValueError('no 3-D chunks found')
    # chunk shape from offsets
    f_off = sorted({o[0] for o in chunks}); s_off = sorted({o[1] for o in chunks}); p_off = sorted({o[2] for o in chunks})
    cf = f_off[1] - f_off[0] if len(f_off) > 1 else None
    cs = s_off[1] - s_off[0] if len(s_off) > 1 else spf
    cp = p_off[1] - p_off[0] if len(p_off) > 1 else npts
    elems = len(next(iter(chunks.values()))) // 4
    if cf is None:
        cf = elems // (cs * cp)
    nf = f_off[-1] + cf
    out = np.zeros((nf, cs * len(s_off), cp * len(p_off), 2), dtype='<i2')
    for (fo, so, po), raw in chunks.items():
        a = np.frombuffer(raw, dtype='<i2').reshape(cf, cs, cp, 2)
        out[fo:fo + cf, so:so + cs, po:po + cp] = a
    out = out[:, :spf, :npts]
    z = out[..., 0].astype(float) + 1j * out[..., 1].astype(float)
    # drop trailing never-written frames
    nz = np.flatnonzero(np.any(z != 0, axis=(1, 2)))
    z = z[: nz[-1] + 1] if len(nz) else z[:0]
    return z, cfg, metadata(b)


def _json_at(b, start):
    depth = 0
    for j in range(start, min(len(b), start + 50000)):
        ch = b[j]
        if ch == 0x7B:
            depth += 1
        elif ch == 0x7D:
            depth -= 1
            if depth == 0:
                return json.loads(b[start:j + 1])
    return None


def session_config(b):
    m = re.search(rb'\{"groups"', b)
    return _json_at(b, m.start())


def metadata(b):
    m = re.search(rb'\{"frame_data_length"', b)
    return _json_at(b, m.start()) if m else {}
