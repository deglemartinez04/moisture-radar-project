"""
moisture_model.py - runs the trained models live (numpy only, no scikit-learn needed).

Models are JSON files written by ml/train_model.py into App/models/:
  stud_model.json     No stud / Stud
  wetness_model.json  Dry / Damp / Saturated
If they are missing, predict() returns None and the dashboard says "no model".

Probabilities are smoothed over the last few updates (exponential average) so the
readout does not flicker; the live window is short (10 frames) compared with a
recording (300 frames), so single live readings are noisier than training rows.
"""
from __future__ import annotations

import json
import math
import os

import numpy as np

from features import add_derived
from ml.feature_set import model_row

MODEL_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")
WETNESS_WEIGHTS = {"Dry": 0.0, "Damp": 0.5, "Saturated": 1.0}


class LinearModel:
    def __init__(self, path):
        with open(path) as f:
            m = json.load(f)
        self.meta = m
        self.features = m["features"]
        self.classes = m["classes"]
        self.mean = np.array(m["mean"], float)
        self.scale = np.array(m["scale"], float)
        self.coef = np.array(m["coef"], float)
        self.intercept = np.array(m["intercept"], float)

    def predict_proba(self, row: dict):
        x = np.array([row.get(k, math.nan) for k in self.features], float)
        if not np.all(np.isfinite(x)):
            return None
        z = self.coef @ ((x - self.mean) / self.scale) + self.intercept
        z -= z.max()
        p = np.exp(z)
        return dict(zip(self.classes, (p / p.sum()).tolist()))


class MoisturePredictor:
    def __init__(self, model_dir=MODEL_DIR, smoothing=0.6):
        self.stud = self._load(os.path.join(model_dir, "stud_model.json"))
        self.wetness = self._load(os.path.join(model_dir, "wetness_model.json"))
        self.alpha = smoothing
        self._stud_p = None
        self._wet_p = None

    @staticmethod
    def _load(path):
        try:
            return LinearModel(path) if os.path.exists(path) else None
        except Exception:
            return None

    @property
    def available(self):
        return self.wetness is not None

    def reset(self):
        self._stud_p = self._wet_p = None

    def _smooth(self, old, new):
        if old is None:
            return new
        return {k: self.alpha * old[k] + (1 - self.alpha) * new[k] for k in new}

    def predict(self, features: dict):
        """features = output of features.extract_features(). Returns a dict or None."""
        if not self.available:
            return None
        row = model_row(add_derived(features))
        out = {}
        if self.stud is not None:
            ps = self.stud.predict_proba(row)
            if ps is not None:
                self._stud_p = self._smooth(self._stud_p, ps)
                out["stud_probability"] = self._stud_p.get("Stud", 0.0)
        pw = self.wetness.predict_proba(row)
        if pw is None:
            return out or None
        self._wet_p = self._smooth(self._wet_p, pw)
        label = max(self._wet_p, key=self._wet_p.get)
        out.update({
            "wetness": label,
            "confidence": self._wet_p[label],
            "probabilities": dict(self._wet_p),
            # 0 = dry ... 100 = saturated; NOT a moisture-content percentage
            "wetness_index": 100.0 * sum(WETNESS_WEIGHTS.get(k, 0) * v for k, v in self._wet_p.items()),
        })
        return out
