"""
moisture_model.py - runs the trained wall models live (numpy only, no scikit-learn needed).

Every *.json file in App/models/ that ml/train_models.py wrote is one selectable model.
All of them answer the same question with the same three classes:
    No stud / Dry stud / Wet stud
so they can be swapped (or compared side by side) in the Moisture Level tab.

Model types understood here (the "type" field of the JSON):
  linear      standardise -> weighted sums -> softmax   (logistic regression, LDA, rules)
  two_stage   linear "is there a stud?" then linear "is the stud wet?"
  forest      average of decision trees                  (random forest)
  boosting    sum of small regression trees -> softmax   (gradient boosting)
  centroids   distance to the average scan of every training session (nearest session)
  mlp         small neural network
  ensemble    average of other model files               (committee)

Probabilities are smoothed over the last few updates (exponential average) so the
readout does not flicker. Each model keeps its own smoothing state.
"""
from __future__ import annotations

import json
import math
import os

import numpy as np

from ml.feature_set import model_row

MODEL_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")
NONE, DRY, WET = "No stud", "Dry stud", "Wet stud"
CLASSES = [NONE, DRY, WET]
DEFAULT_MODEL_FILE = "wall_model.json"


def _softmax(z):
    z = np.asarray(z, float)
    z = z - z.max()
    p = np.exp(z)
    return p / p.sum()


class _Base:
    """x = feature vector in the order of spec["features"]; returns probabilities in CLASSES order."""

    def __init__(self, spec):
        self.features = spec["features"]
        self.classes = spec.get("classes", CLASSES)

    def vector(self, row):
        x = np.array([row.get(k, math.nan) for k in self.features], float)
        return x if np.all(np.isfinite(x)) else None

    def proba(self, row):
        x = self.vector(row)
        if x is None:
            return None
        p = self._proba(x)
        d = dict(zip(self.classes, np.asarray(p, float).tolist()))
        return np.array([d.get(c, 0.0) for c in CLASSES])


class _Linear(_Base):
    def __init__(self, spec):
        super().__init__(spec)
        self.project = np.array(spec["project"], float) if spec.get("project") else None
        self.mean = np.array(spec["mean"], float)
        self.scale = np.array(spec["scale"], float)
        self.coef = np.array(spec["coef"], float)
        self.intercept = np.array(spec["intercept"], float)

    def _proba(self, x):
        if self.project is not None:
            x = self.project @ x
        return _softmax(self.coef @ ((x - self.mean) / self.scale) + self.intercept)


class _TwoStage(_Base):
    def __init__(self, spec):
        super().__init__(spec)
        self.stud = _Linear(spec["stud"])      # classes: No stud, Stud
        self.wet = _Linear(spec["wet"])        # classes: Dry stud, Wet stud

    def proba(self, row):
        xs, xw = self.stud.vector(row), self.wet.vector(row)
        if xs is None or xw is None:
            return None
        ps = dict(zip(self.stud.classes, self.stud._proba(xs)))
        pw = dict(zip(self.wet.classes, self.wet._proba(xw)))
        stud = ps["Stud"]
        return np.array([ps[NONE], stud * pw[DRY], stud * pw[WET]])


def _tree_leaf(tree, x):
    feat, thr, left, right = tree["feature"], tree["threshold"], tree["left"], tree["right"]
    n = 0
    while left[n] != -1:
        n = left[n] if x[feat[n]] <= thr[n] else right[n]
    return n


class _Forest(_Base):
    def __init__(self, spec):
        super().__init__(spec)
        self.trees = spec["trees"]

    def _proba(self, x):
        acc = np.zeros(len(self.classes))
        for t in self.trees:
            acc += t["value"][_tree_leaf(t, x)]
        return acc / len(self.trees)


class _Boosting(_Base):
    def __init__(self, spec):
        super().__init__(spec)
        self.init = np.array(spec["init"], float)
        self.rate = float(spec["learning_rate"])
        self.stages = spec["stages"]            # [stage][class] -> tree with one value per node

    def _proba(self, x):
        raw = self.init.copy()
        for stage in self.stages:
            for k, t in enumerate(stage):
                raw[k] += self.rate * t["value"][_tree_leaf(t, x)]
        return _softmax(raw)


class _Centroids(_Base):
    def __init__(self, spec):
        super().__init__(spec)
        self.mean = np.array(spec["mean"], float)
        self.scale = np.array(spec["scale"], float)
        self.centroids = np.array(spec["centroids"], float)
        self.labels = spec["labels"]            # class of each centroid
        self.names = spec.get("names", [])
        self.temperature = float(spec["temperature"])
        self.nearest = ""

    def _proba(self, x):
        z = (x - self.mean) / self.scale
        d2 = ((self.centroids - z) ** 2).mean(axis=1)
        w = _softmax(-d2 / self.temperature)
        if self.names:
            self.nearest = self.names[int(np.argmin(d2))]
        return np.array([sum(w[i] for i, lab in enumerate(self.labels) if lab == c) for c in self.classes])


class _MLP(_Base):
    def __init__(self, spec):
        super().__init__(spec)
        self.mean = np.array(spec["mean"], float)
        self.scale = np.array(spec["scale"], float)
        self.weights = [np.array(w, float) for w in spec["weights"]]
        self.biases = [np.array(b, float) for b in spec["biases"]]

    def _proba(self, x):
        a = (x - self.mean) / self.scale
        for w, b in zip(self.weights[:-1], self.biases[:-1]):
            a = np.maximum(a @ w + b, 0.0)
        return _softmax(a @ self.weights[-1] + self.biases[-1])


class _Ensemble:
    def __init__(self, spec, model_dir):
        self.members = [build(_read(os.path.join(model_dir, f)), model_dir) for f in spec["members"]]

    def proba(self, row):
        ps = [m.proba(row) for m in self.members]
        ps = [p for p in ps if p is not None]
        return np.mean(ps, axis=0) if ps else None


_TYPES = {"linear": _Linear, "standardized_logistic_regression": _Linear, "two_stage": _TwoStage,
          "forest": _Forest, "boosting": _Boosting, "centroids": _Centroids, "mlp": _MLP}


def _read(path):
    with open(path) as f:
        return json.load(f)


def build(spec, model_dir=MODEL_DIR):
    if spec["type"] == "ensemble":
        return _Ensemble(spec, model_dir)
    return _TYPES[spec["type"]](spec)


class WallModel:
    """One selectable model: metadata + smoothed prediction."""

    def __init__(self, path, smoothing=0.6):
        spec = _read(path)
        self.file = os.path.basename(path)
        self.meta = {k: v for k, v in spec.items() if not isinstance(v, (list, dict)) or k == "members"}
        self.name = str(spec.get("name") or spec.get("dataset") or self.file)
        self.description = str(spec.get("description", ""))
        self.score = str(spec.get("sessions_correct", ""))
        self.impl = build(spec, os.path.dirname(path))
        self.alpha = smoothing
        self._p = None

    def reset(self):
        self._p = None

    def predict(self, row):
        p = self.impl.proba(row)
        if p is None:
            return None
        p = np.clip(p, 0.0, None)
        p = p / p.sum() if p.sum() > 0 else np.full(len(CLASSES), 1.0 / len(CLASSES))
        if self._p is not None:
            p = self.alpha * self._p + (1 - self.alpha) * p
        self._p = p
        k = int(np.argmax(p))
        return {
            "label": CLASSES[k],
            "confidence": float(p[k]),
            "probabilities": dict(zip(CLASSES, p.tolist())),
            "wet_probability": float(p[CLASSES.index(WET)]),
            "stud_probability": float(1.0 - p[CLASSES.index(NONE)]),
            "nearest": getattr(self.impl, "nearest", ""),
        }


class MoisturePredictor:
    """All models found in App/models; one of them is the selected one."""

    def __init__(self, model_dir=MODEL_DIR, smoothing=0.6):
        self.models = []
        self.errors = []
        if os.path.isdir(model_dir):
            # the V15 model first, then the others in file-name order
            for f in sorted(os.listdir(model_dir), key=lambda n: (n != DEFAULT_MODEL_FILE, n)):
                if not f.endswith(".json"):
                    continue
                try:
                    self.models.append(WallModel(os.path.join(model_dir, f), smoothing))
                except Exception as exc:        # a broken file must not stop the app
                    self.errors.append(f"{f}: {exc}")
        self.selected = 0

    @property
    def available(self):
        return bool(self.models)

    @property
    def current(self):
        return self.models[self.selected] if self.models else None

    @property
    def model_name(self):
        return self.current.name if self.current else "none"

    def select(self, file_or_index):
        """Choose the model by file name or list position. Returns True if it changed."""
        if isinstance(file_or_index, int):
            idx = file_or_index if 0 <= file_or_index < len(self.models) else None
        else:
            idx = next((i for i, m in enumerate(self.models) if m.file == file_or_index), None)
        if idx is None or idx == self.selected:
            return False
        self.selected = idx
        self.models[idx].reset()
        return True

    def reset(self):
        for m in self.models:
            m.reset()

    def predict(self, features: dict):
        """features = output of features.extract_features(). Result of the selected model, or None."""
        if not self.available:
            return None
        return self.current.predict(model_row(features))

    def predict_all(self, features: dict):
        """[(model, result or None)] for every model - used by the comparison table."""
        row = model_row(features)
        return [(m, m.predict(row)) for m in self.models]
