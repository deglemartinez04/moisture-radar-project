"""
feature_set.py - the ONE list of model inputs, shared by build_dataset.py,
train_model.py and the live predictor (moisture_model.py).

v15: the main-echo profile from features._echo_profile (see the comment there):
  e{10..70}_db          how fast the wall echo dies away behind its peak, every 5 mm   (13)
  e{10,20..70}_re/_im   the same trailing edge as complex values, every 10 mm          (14)
All of them are ratios to the echo itself, so gain, temperature and the exact placement
phase cancel. They assume the fixed 50 mm standoffs.

Never inputs: moisture_level, water_amount_ml, time_since_wet_min, trial_number,
sample_id, standoff_mm, recorded_at, background_id, temperatures (labels / conditions),
and echo_distance_m / echo_amplitude_db (they differ from mounting to mounting more than
between dry and wet; kept for the "no wall" gate only).
"""
from __future__ import annotations

from features import ECHO_DB_OFFSETS_MM, ECHO_IQ_OFFSETS_MM

ECHO_DB = [f"e{o}_db" for o in ECHO_DB_OFFSETS_MM]
ECHO_IQ = [f"e{o}_{c}" for o in ECHO_IQ_OFFSETS_MM for c in ("re", "im")]
MODEL_FEATURES = ECHO_DB + ECHO_IQ
GATE_FEATURES = ["echo_distance_m", "echo_amplitude_db"]


def _f(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return float("nan")


def model_row(features: dict) -> dict:
    """Pick MODEL_FEATURES (+ gate values) from features.extract_features()."""
    return {k: _f(features.get(k)) for k in MODEL_FEATURES + GATE_FEATURES}
