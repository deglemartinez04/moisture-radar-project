"""
train_models.py - train, test and export EVERY selectable wall model from ml_dataset.csv.

All models answer No stud / Dry stud / Wet stud from the same 27 inputs (feature_set.py)
and are written to App/models/*.json, where the app finds them (numpy-only runtime in
moisture_model.py). The Moisture Level tab lists them in file-name order.

  wall_model.json            Logistic regression - the V15 model, unchanged
  m02_logistic_strength.json Logistic regression on signal strength only (no phase)
  m03_logistic_wet_alert.json Logistic regression that says Wet more readily (missed wet costs 3x)
  m04_two_stage.json         Two questions: "stud?" then "wet?" (two logistic models)
  m05_lda.json               Linear discriminant analysis (shrinkage)
  m06_random_forest.json     Random forest (200 trees)
  m07_boosting.json          Gradient-boosted trees
  m08_nearest_session.json   Nearest session: which recorded session does this scan resemble?
  m09_neural_net.json        Small neural network (one hidden layer of 8)
  m10_tail_rule.json         Simple rule: 3 numbers describing the signal behind the wall
  m11_committee.json         Committee: average of models 1-10

Test - leave-one-BOARD-out, identical for every model: all scans of one board (dry AND wet)
are removed, the model is trained on the rest and judged on the removed board. Scans of
one session are near-copies, so whole SESSIONS are counted.

After export each model is run again through the app's own numpy code and compared with
scikit-learn; a mismatch stops the script.

Usage (from the App folder; needs scikit-learn + pandas on the training PC):
  python -m ml.train_models --data ml/ml_dataset.csv --out models
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import sys
import warnings

import numpy as np
import pandas as pd
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score, roc_auc_score
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import moisture_model                                              # noqa: E402
from ml.build_dataset import WALL_CLASSES                           # noqa: E402
from ml.feature_set import ECHO_DB, MODEL_FEATURES                  # noqa: E402

NONE, DRY, WET = WALL_CLASSES
F = MODEL_FEATURES


# ----------------------------------------------------------------------------
# weights: classes equal; optionally every session equal inside its class
# ----------------------------------------------------------------------------
def class_weights(y):
    w = np.ones(len(y))
    for c in np.unique(y):
        w[y == c] = len(y) / (len(np.unique(y)) * (y == c).sum())
    return w


def session_weights(y, sessions):
    w = np.ones(len(y))
    for c in np.unique(y):
        ses = np.unique(sessions[y == c])
        for s in ses:
            k = (y == c) & (sessions == s)
            w[k] = 1.0 / (len(ses) * k.sum())
    return w * len(y) / w.sum()


def reorder(p, classes, target=WALL_CLASSES):
    out = np.zeros((p.shape[0], len(target)))
    for j, c in enumerate(classes):
        out[:, target.index(c)] = p[:, j]
    return out


def linear_spec(scaler, coef, intercept, classes, features, project=None):
    coef, intercept = np.asarray(coef), np.asarray(intercept)
    if coef.shape[0] == 1:                 # binary -> two rows so the runtime is always softmax
        coef = np.vstack([-coef[0] / 2, coef[0] / 2])
        intercept = np.array([-intercept[0] / 2, intercept[0] / 2])
    spec = {"type": "linear", "features": features, "classes": [str(c) for c in classes],
            "mean": scaler.mean_.tolist(), "scale": scaler.scale_.tolist(),
            "coef": coef.tolist(), "intercept": intercept.tolist()}
    if project is not None:
        spec["project"] = np.asarray(project).tolist()
    return spec


# ----------------------------------------------------------------------------
# model definitions: fit(X, y, sessions) -> (predict_proba(X) in WALL_CLASSES order, spec)
# X always has the columns of MODEL_FEATURES.
# ----------------------------------------------------------------------------
def fit_logistic(X, y, sessions, cols=None, C=0.01, wet_boost=1.0, project=None):
    idx = [F.index(c) for c in (cols or F)]
    P = None if project is None else np.asarray(project)

    def prep(A):
        A = A[:, idx]
        return A if P is None else A @ P.T
    sc = StandardScaler().fit(prep(X))
    clf = LogisticRegression(C=C, max_iter=5000)
    w = class_weights(y)
    w[y == WET] *= wet_boost          # > 1: missing a wet stud costs more than a false alarm
    clf.fit(sc.transform(prep(X)), y, sample_weight=w)
    spec = linear_spec(sc, clf.coef_, clf.intercept_, clf.classes_, [F[i] for i in idx], P)
    return (lambda A: reorder(clf.predict_proba(sc.transform(prep(A))), list(clf.classes_))), spec


def fit_two_stage(X, y, sessions, C=0.01):
    sc = StandardScaler().fit(X)
    ys = np.where(y == NONE, NONE, "Stud").astype(object)
    stud = LogisticRegression(C=C, max_iter=5000).fit(sc.transform(X), ys, sample_weight=class_weights(ys))
    m = y != NONE
    sc2 = StandardScaler().fit(X[m])
    wet = LogisticRegression(C=C, max_iter=5000).fit(sc2.transform(X[m]), y[m], sample_weight=class_weights(y[m]))

    def proba(A):
        ps = reorder(stud.predict_proba(sc.transform(A)), list(stud.classes_), [NONE, "Stud"])
        pw = reorder(wet.predict_proba(sc2.transform(A)), list(wet.classes_), [DRY, WET])
        return np.column_stack([ps[:, 0], ps[:, 1] * pw[:, 0], ps[:, 1] * pw[:, 1]])
    spec = {"type": "two_stage", "features": F, "classes": WALL_CLASSES,
            "stud": linear_spec(sc, stud.coef_, stud.intercept_, stud.classes_, F),
            "wet": linear_spec(sc2, wet.coef_, wet.intercept_, wet.classes_, F)}
    return proba, spec


def fit_lda(X, y, sessions):
    sc = StandardScaler().fit(X)
    n = len(np.unique(y))
    clf = LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto", priors=np.full(n, 1.0 / n))
    clf.fit(sc.transform(X), y)
    spec = linear_spec(sc, clf.coef_, clf.intercept_, clf.classes_, F)
    return (lambda A: reorder(clf.predict_proba(sc.transform(A)), list(clf.classes_))), spec


def _tree(t, value):
    return {"feature": t.feature.tolist(), "threshold": t.threshold.tolist(),
            "left": t.children_left.tolist(), "right": t.children_right.tolist(), "value": value}


def fit_forest(X, y, sessions):
    clf = RandomForestClassifier(n_estimators=200, max_depth=6, min_samples_leaf=5, random_state=0)
    clf.fit(X, y, sample_weight=session_weights(y, sessions))
    trees = []
    for e in clf.estimators_:
        v = e.tree_.value[:, 0, :]
        trees.append(_tree(e.tree_, np.round(v / v.sum(axis=1, keepdims=True), 5).tolist()))
    spec = {"type": "forest", "features": F, "classes": [str(c) for c in clf.classes_], "trees": trees}
    return (lambda A: reorder(clf.predict_proba(A), list(clf.classes_))), spec


def fit_boosting(X, y, sessions):
    clf = GradientBoostingClassifier(n_estimators=60, max_depth=2, learning_rate=0.1, subsample=0.7,
                                     min_samples_leaf=5, random_state=0)
    clf.fit(X, y, sample_weight=session_weights(y, sessions))
    stages = [[_tree(e.tree_, e.tree_.value[:, 0, 0].tolist()) for e in stage] for stage in clf.estimators_]
    raw = clf.decision_function(X[:1])[0]
    add = np.array([clf.learning_rate * sum(st[k].predict(X[:1])[0] for st in clf.estimators_)
                    for k in range(len(clf.classes_))])
    spec = {"type": "boosting", "features": F, "classes": [str(c) for c in clf.classes_],
            "init": (raw - add).tolist(), "learning_rate": clf.learning_rate, "stages": stages}
    return (lambda A: reorder(clf.predict_proba(A), list(clf.classes_))), spec


def fit_centroids(X, y, sessions, temperature=0.25):
    sc = StandardScaler().fit(X)
    Z = sc.transform(X)
    names = list(dict.fromkeys(sessions))
    cent = np.array([Z[sessions == s].mean(axis=0) for s in names])
    labels = [str(y[sessions == s][0]) for s in names]

    def proba(A):
        z = sc.transform(A)
        d2 = ((z[:, None, :] - cent[None, :, :]) ** 2).mean(axis=2)
        w = np.exp(-(d2 - d2.min(axis=1, keepdims=True)) / temperature)
        w /= w.sum(axis=1, keepdims=True)
        return np.column_stack([w[:, [i for i, lab in enumerate(labels) if lab == c]].sum(axis=1)
                                for c in WALL_CLASSES])
    spec = {"type": "centroids", "features": F, "classes": WALL_CLASSES, "mean": sc.mean_.tolist(),
            "scale": sc.scale_.tolist(), "centroids": cent.tolist(), "labels": labels,
            "names": names, "temperature": temperature}
    return proba, spec


def fit_mlp(X, y, sessions):
    # MLP has no class weights here: build a balanced training set instead
    # (10 evenly spaced scans of every session; the single drywall session 5 times).
    keep = []
    for s in dict.fromkeys(sessions):
        i = np.where(sessions == s)[0]
        pick = i[np.linspace(0, len(i) - 1, min(10, len(i))).round().astype(int)]
        keep += list(pick) * (5 if y[i[0]] == NONE else 1)
    keep = np.array(keep)
    sc = StandardScaler().fit(X)
    clf = MLPClassifier(hidden_layer_sizes=(8,), alpha=3.0, solver="lbfgs", max_iter=3000, random_state=0)
    clf.fit(sc.transform(X[keep]), y[keep])
    spec = {"type": "mlp", "features": F, "classes": [str(c) for c in clf.classes_],
            "mean": sc.mean_.tolist(), "scale": sc.scale_.tolist(),
            "weights": [w.tolist() for w in clf.coefs_], "biases": [b.tolist() for b in clf.intercepts_]}
    return (lambda A: reorder(clf.predict_proba(sc.transform(A)), list(clf.classes_))), spec


# three hand-made numbers: average level 10-25, 30-50 and 55-70 mm behind the wall echo
TAIL_BANDS = [("near (10-25 mm)", range(10, 30, 5)), ("middle (30-50 mm)", range(30, 55, 5)),
              ("far (55-70 mm)", range(55, 75, 5))]
TAIL_PROJECT = [[(1.0 / len(list(r)) if c in [f"e{o}_db" for o in r] else 0.0) for c in ECHO_DB]
                for _, r in TAIL_BANDS]

MODELS = [
    ("wall_model.json", "Logistic (V15)", "Logistic regression on all 27 inputs. The V15 model, unchanged.",
     lambda X, y, s: fit_logistic(X, y, s)),
    ("m02_logistic_strength.json", "Logistic, strength only",
     "Logistic regression on the 13 signal-strength inputs; ignores phase.",
     lambda X, y, s: fit_logistic(X, y, s, cols=ECHO_DB)),
    ("m03_logistic_wet_alert.json", "Logistic, wet-alert",
     "Same as the V15 model but a missed wet stud costs 3x a false alarm: says Wet more readily.",
     lambda X, y, s: fit_logistic(X, y, s, wet_boost=3.0)),
    ("m04_two_stage.json", "Two-stage logistic", "First decides stud / no stud, then dry / wet for studs.",
     fit_two_stage),
    ("m05_lda.json", "LDA", "Linear discriminant analysis with shrinkage.", fit_lda),
    ("m06_random_forest.json", "Random forest", "200 decision trees, session-balanced.", fit_forest),
    ("m07_boosting.json", "Gradient boosting", "60 rounds of small boosted trees, session-balanced.", fit_boosting),
    ("m08_nearest_session.json", "Nearest session",
     "Compares the scan with the average scan of each recorded session.", fit_centroids),
    ("m09_neural_net.json", "Neural network", "One hidden layer of 8 units, strongly regularised.", fit_mlp),
    ("m10_tail_rule.json", "Tail rule (3 numbers)",
     "Logistic regression on three averages: signal 10-25, 30-50 and 55-70 mm behind the wall echo.",
     lambda X, y, s: fit_logistic(X, y, s, cols=ECHO_DB, C=1.0, project=TAIL_PROJECT)),
]
COMMITTEE = ("m11_committee.json", "Committee (average of 1-10)", "Average of the ten models above.")


# ----------------------------------------------------------------------------
def leave_one_board_out(fit, X, y, sessions, groups):
    proba = np.zeros((len(y), len(WALL_CLASSES)))
    for g in np.unique(groups):
        te = groups == g
        p, _ = fit(X[~te], y[~te], sessions[~te])
        proba[te] = p(X[te])
    return proba


def score(y, proba, sessions):
    pred = np.array(WALL_CLASSES, dtype=object)[proba.argmax(axis=1)]
    rows = []
    for s in dict.fromkeys(sessions):
        k = sessions == s
        maj = pd.Series(pred[k]).value_counts().idxmax()
        rows.append({"session": s, "true": y[k][0], "majority": maj, "ok": maj == y[k][0],
                     "p_wet": proba[k, 2].mean(), "p_stud": 1 - proba[k, 0].mean()})
    st = pd.DataFrame(rows)
    studs = st[st["true"] != NONE]
    out = {
        "sessions_ok": int(st["ok"].sum()), "sessions": len(st),
        "dry_ok": int(st[st["true"] == DRY]["ok"].sum()), "dry_n": int((st["true"] == DRY).sum()),
        "wet_ok": int(st[st["true"] == WET]["ok"].sum()), "wet_n": int((st["true"] == WET).sum()),
        "none_ok": int(st[st["true"] == NONE]["ok"].sum()), "none_n": int((st["true"] == NONE).sum()),
        "scan_bal_acc": balanced_accuracy_score(y, pred),
        "pwet_dry": studs[studs["true"] == DRY]["p_wet"].mean(),
        "pwet_wet": studs[studs["true"] == WET]["p_wet"].mean(),
        # chance that a random wet session gets a higher wet probability than a random dry session
        "wet_ranking": roc_auc_score((studs["true"] == WET).astype(int), studs["p_wet"]),
    }
    return out, st


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", default=os.path.join(HERE, "ml_dataset.csv"))
    ap.add_argument("--out", default=os.path.join(os.path.dirname(HERE), "models"))
    ap.add_argument("--title", default="V16", help="dataset name written into every JSON")
    a = ap.parse_args()
    warnings.filterwarnings("ignore")
    os.makedirs(a.out, exist_ok=True)

    full = pd.read_csv(a.data)
    df = full[(full["quality_ok"] == 1) & full["wall_class"].isin(WALL_CLASSES)].reset_index(drop=True)
    X = df[F].to_numpy(float)
    y = df["wall_class"].to_numpy(object)
    groups = df["cv_group"].to_numpy(object)
    sessions = (df["meta_folder"] + " [" + df["material"] + "]").to_numpy(object)
    rows = df[F].to_dict("records")

    results, tables, loo, names = [], {}, [], []
    for file, name, desc, fit in MODELS:
        proba = leave_one_board_out(fit, X, y, sessions, groups)
        loo.append(proba)
        sc, st = score(y, proba, sessions)
        final_proba, spec = fit(X, y, sessions)
        spec.update({"name": name, "description": desc, "dataset": a.title, "n_rows": int(len(y)),
                     "trained_at": dt.datetime.now().isoformat(timespec="seconds"),
                     "sessions_correct": f"{sc['sessions_ok']}/{sc['sessions']}",
                     "wet_sessions_correct": f"{sc['wet_ok']}/{sc['wet_n']}",
                     "dry_sessions_correct": f"{sc['dry_ok']}/{sc['dry_n']}"})
        path = os.path.join(a.out, file)
        with open(path, "w") as f:
            json.dump(spec, f)
        # the app's numpy code must give the same numbers as scikit-learn
        rt = moisture_model.WallModel(path, smoothing=0.0)
        got = np.array([rt.impl.proba(r) for r in rows])
        err = float(np.abs(got - final_proba(X)).max())
        if err > 1e-3:
            raise SystemExit(f"{file}: app runtime differs from scikit-learn by {err:.4f}")
        results.append({"file": file, "model": name, **sc, "runtime_check": err})
        tables[name] = st
        names.append(name)
        print(f"  {name}: {sc['sessions_ok']}/{sc['sessions']} sessions, runtime check {err:.1e}", flush=True)

    file, name, desc = COMMITTEE
    proba = np.mean(loo, axis=0)
    sc, st = score(y, proba, sessions)
    with open(os.path.join(a.out, file), "w") as f:
        json.dump({"type": "ensemble", "name": name, "description": desc, "dataset": a.title,
                   "members": [m[0] for m in MODELS], "features": F, "classes": WALL_CLASSES,
                   "sessions_correct": f"{sc['sessions_ok']}/{sc['sessions']}",
                   "wet_sessions_correct": f"{sc['wet_ok']}/{sc['wet_n']}",
                   "dry_sessions_correct": f"{sc['dry_ok']}/{sc['dry_n']}"}, f)
    moisture_model.WallModel(os.path.join(a.out, file))
    results.append({"file": file, "model": name, **sc, "runtime_check": 0.0})
    tables[name] = st
    names.append(name)

    res = pd.DataFrame(results)
    summary = pd.DataFrame({
        "model": res["model"],
        "sessions": res["sessions_ok"].astype(str) + "/" + res["sessions"].astype(str),
        "dry": res["dry_ok"].astype(str) + "/" + res["dry_n"].astype(str),
        "wet": res["wet_ok"].astype(str) + "/" + res["wet_n"].astype(str),
        "no stud": res["none_ok"].astype(str) + "/" + res["none_n"].astype(str),
        "scan bal.acc": res["scan_bal_acc"].round(2),
        "P(wet) dry": res["pwet_dry"].round(2),
        "P(wet) wet": res["pwet_wet"].round(2),
        "wet ranking": res["wet_ranking"].round(2),
    })
    out = [f"Model comparison {a.title}  {dt.datetime.now():%Y-%m-%d %H:%M}",
           f"{len(df)} recordings, {len(F)} inputs, {len(np.unique(sessions))} sessions, leave-one-board-out",
           "",
           "sessions / dry / wet / no stud = sessions whose majority answer was right",
           "P(wet) dry, P(wet) wet = average wet probability on held-out dry and wet stud sessions",
           "wet ranking = chance a wet session scores a higher wet probability than a dry one (0.5 = coin flip)",
           "", summary.to_string(index=False), "",
           "=== which sessions each model got wrong (majority answer in brackets) ==="]
    for n in names:
        bad = tables[n][~tables[n]["ok"]]
        out.append(f"  {n}: " + ("none" if bad.empty else
                   "; ".join(f"{r.session.split(' [')[0]} ({r.majority})" for r in bad.itertuples())))
    out.append("\n=== mean wet probability per held-out stud session ===")
    pw = pd.DataFrame({n: tables[n].set_index("session")["p_wet"] for n in names}).round(2)
    pw.index = [i.split(" [")[0] for i in pw.index]
    pw.columns = [f"m{i + 1:02d}" for i in range(len(names))]
    out.append("columns: " + ", ".join(f"{c}={n}" for c, n in zip(pw.columns, names)))
    out.append(pw.to_string())
    text = "\n".join(out)
    print(text)
    with open(os.path.join(a.out, "training_report.txt"), "w") as f:
        f.write(text + "\n")
    summary.to_csv(os.path.join(a.out, "model_comparison.csv"), index=False)


if __name__ == "__main__":
    main()
