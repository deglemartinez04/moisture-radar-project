"""
build_dataset.py - turn Data Logging folders into ONE clean table for machine learning (v15).

Every row is recomputed from its .h5 recording with the SAME code the live app uses
(close_range.process_frame + features.extract_features), with the recording's own
*_background.npz and TX-off noise level. Feature columns stored in the CSVs are not used,
so recordings made by older app versions still get the newest features.

What it does
  1. Finds every data_log*.csv under --root (or takes --csv files). Folders whose name
     contains one of --exclude (default: "old") are skipped and listed.
  2. Re-processes each .h5. A file renamed after logging (Dry_12.h5 -> Saturated_12.h5) is
     found again through its trial number.
  3. Cleans the labels into one column, wall_class:
         Drywall                      -> "No stud"
         Wood + drywall, Dry          -> "Dry stud"
         Wood + drywall, Damp/Saturated -> "Wet stud"
         anything else (Wood alone, Open air) -> "" (reference rows, not used for training)
     Optional label_overrides.csv: columns folder,h5_file,wetness,material,sample_id,exclude,note.
  4. Adds cv_group = the physical board (S1..S10): all scans of one board, dry AND wet, are
     held out together in cross-validation. Drywall-only scans get drywall#1, #2 ... (a new
     group after every pause longer than 30 min).
  5. Adds quality_ok / quality_reason. Columns that must never be model inputs stay as meta_*.

Usage (from the App folder):
  python -m ml.build_dataset --root "D:/logs" --out ml/ml_dataset.csv
"""
from __future__ import annotations

import argparse
import glob
import math
import os
import sys

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))          # App folder

from close_range import process_frame                               # noqa: E402
from features import MIN_ECHO_AMPLITUDE_DB, extract_features         # noqa: E402
from ml import h5io                                                  # noqa: E402
from ml.feature_set import MODEL_FEATURES, model_row                 # noqa: E402

WALL_CLASSES = ["No stud", "Dry stud", "Wet stud"]


def wall_class(material, wetness):
    if material == "Drywall":
        return "No stud"
    if material == "Wood + drywall":
        return "Dry stud" if wetness == "Dry" else "Wet stud"
    return ""


def corrected_sweeps(h5_path, background, use_filter=True):
    rec = h5io.load(h5_path)
    rf, lb = rec.range_frames, rec.loopback_frames
    corr = np.stack([
        process_frame(rf[k], None if lb is None else lb[k], background,
                      rec.profile, rec.step_length, rec.start_point, use_filter)[1]
        for k in range(rf.shape[0])
    ])
    d = (rec.start_point + np.arange(rf.shape[2]) * rec.step_length) * rec.base_step_length_m
    return corr, d


def load_overrides(path):
    if not path or not os.path.exists(path):
        return {}
    ov = pd.read_csv(path, dtype=str).fillna("")
    return {(r["folder"], r["h5_file"]): r for _, r in ov.iterrows()}


def find_csvs(root, exclude):
    keep, skipped = [], []
    for p in sorted(glob.glob(os.path.join(glob.escape(root), "**", "data_log*.csv"), recursive=True)):
        name = os.path.basename(os.path.dirname(p)).lower()
        (skipped if any(x.lower() in name for x in exclude) else keep).append(p)
    return keep, skipped


def build(csv_paths, overrides_path=None, use_filter=True, progress=True):
    overrides = load_overrides(overrides_path)
    rows = []
    for csv_path in csv_paths:
        folder = os.path.dirname(os.path.abspath(csv_path))
        fname = os.path.basename(folder)
        df = pd.read_csv(csv_path)
        n0 = len(rows)
        for _, r in df.iterrows():
            h5 = r.get("h5_file")
            if not isinstance(h5, str) or not h5:
                continue
            h5_path, renamed = os.path.join(folder, h5), 0
            if not os.path.exists(h5_path):
                alt = glob.glob(os.path.join(glob.escape(folder), f"*_{int(r['trial_number'])}.h5"))
                if len(alt) != 1:
                    print(f"  {fname}: missing {h5}, skipped")
                    continue
                h5_path, h5, renamed = alt[0], os.path.basename(alt[0]), 1
            bg_path = os.path.splitext(h5_path)[0] + "_background.npz"
            background = np.load(bg_path)["background_iq"] if os.path.exists(bg_path) else None
            noise = float(r["noise_floor"]) if str(r.get("noise_source", "")) == "tx_off" else None
            zero = float(r.get("zero_offset_m", 0.0) or 0.0)
            corr, d_raw = corrected_sweeps(h5_path, background, use_filter)
            d = d_raw - (0.0 if math.isnan(zero) else zero)
            f = extract_features(np.abs(corr), np.angle(corr), d,
                                 background_corrected=background is not None, noise_level=noise)
            label = {"material": str(r["material"]), "sample_id": str(r["sample_id"]),
                     "wetness": str(r["moisture_level"])}
            ov = overrides.get((fname, h5))
            excluded = False
            if ov is not None:
                for k in label:
                    if ov.get(k):
                        label[k] = ov[k]
                excluded = str(ov.get("exclude", "")).strip().lower() in ("1", "true", "yes")
            out = {
                "meta_folder": fname,
                "meta_h5_file": h5,
                "meta_h5_renamed": renamed,
                "meta_trial_number": r.get("trial_number"),
                "meta_recorded_at": r["recorded_at"],
                "meta_date": str(r["recorded_at"])[:10],
                "meta_background_id": r.get("background_id", ""),
                "meta_logged_moisture_level": r["moisture_level"],
                "meta_sensor_temperature_c": r.get("sensor_temperature_c"),
                "meta_num_frames": corr.shape[0],
                "meta_background_applied": int(background is not None),
                "meta_excluded": int(excluded),
                "standoff_mm": float(r["measured_distance_mm"]),
                "material": label["material"],
                "sample_id": label["sample_id"],
                "wetness": label["wetness"],
                "wall_class": wall_class(label["material"], label["wetness"]),
            }
            out.update(model_row(f))
            rows.append(out)
        if progress:
            print(f"  {fname}: {len(rows) - n0} recordings", flush=True)
    data = pd.DataFrame(rows)
    data["meta_recorded_at"] = pd.to_datetime(data["meta_recorded_at"])
    data = data.sort_values(["meta_folder", "meta_recorded_at"]).reset_index(drop=True)
    data["meta_minutes_in_session"] = data.groupby(["meta_folder", "material"])["meta_recorded_at"].transform(
        lambda t: (t - t.min()).dt.total_seconds() / 60.0).round(1)
    data["cv_group"] = data["sample_id"]
    dw = data["material"] == "Drywall"
    if dw.any():
        t = data.loc[dw, "meta_recorded_at"].sort_values()
        block = (t.diff().dt.total_seconds().fillna(0) > 1800).cumsum() + 1
        data.loc[block.index, "cv_group"] = "drywall#" + block.astype(str)
    quality(data)
    return data


def quality(data):
    reasons = []
    feat_ok = data[MODEL_FEATURES].notna().all(axis=1)
    for i in data.index:
        r = []
        if not data.at[i, "meta_background_applied"]:
            r.append("no background file")
        if not feat_ok[i]:
            r.append("scan range does not cover the wall echo + 70 mm")
        elif data.at[i, "wall_class"] and data.at[i, "echo_amplitude_db"] < MIN_ECHO_AMPLITUDE_DB:
            r.append("wall echo too weak (no wall in front of the sensor?)")
        if data.at[i, "meta_excluded"]:
            r.append("excluded by label override")
        reasons.append("; ".join(r))
    data["quality_reason"] = reasons
    data["quality_ok"] = (data["quality_reason"] == "").astype(int)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--root", help="folder that contains the Data Logging folders (searched recursively)")
    ap.add_argument("--csv", nargs="*", default=[], help="or: individual data_log.csv files")
    ap.add_argument("--exclude", nargs="*", default=["old"],
                    help="skip folders whose name contains one of these words (default: old)")
    ap.add_argument("--labels", default=os.path.join(HERE, "label_overrides.csv"))
    ap.add_argument("--out", default=os.path.join(HERE, "ml_dataset.csv"))
    ap.add_argument("--no-filter", action="store_true", help="match recordings made with the distance filter off")
    a = ap.parse_args()
    csvs, skipped = list(a.csv), []
    if a.root:
        found, skipped = find_csvs(a.root, a.exclude)
        csvs += found
    if not csvs:
        ap.error("no data_log*.csv found: give --root or --csv")
    for p in skipped:
        print(f"  skipped (excluded): {os.path.dirname(p)}")
    data = build(csvs, a.labels, use_filter=not a.no_filter)
    data.to_csv(a.out, index=False)
    print(f"wrote {a.out}: {len(data)} rows, {int(data.quality_ok.sum())} pass quality")
    print(data.assign(wall_class=data.wall_class.replace("", "(reference only)"))
          .groupby(["material", "wetness", "wall_class"]).size().to_string())


if __name__ == "__main__":
    main()
