# Machine learning workflow (V16)

```
Data Logging folders (data_log.csv + .h5 + *_background.npz)
        |  python -m ml.build_dataset --root <folder with all batches> --out ml/ml_dataset.csv
        v
ml/ml_dataset.csv   one clean row per recording: meta_*, labels, wall_class, 27 model features, quality_ok
        |  python -m ml.train_models --data ml/ml_dataset.csv --out models     (needs scikit-learn + pandas)
        v
App/models/*.json (11 models) + training_report.txt + model_comparison.csv
        v                                             loaded by moisture_model.py (numpy only)
Moisture Level tab:  Model picker + "Compare all";  No stud / Dry stud / Wet stud + confidence + wet probability
```

## V16: several models, switchable in the app
* Every `*.json` in `App/models/` is one entry of the **Model** list on the Moisture Level tab.
  The choice is remembered. **Compare all** runs every model on the same live scan in one table
  (answer, wet %, stud %); tap a row to select that model.
* To remove a model from the list delete its file (the committee needs models 1-10). To add
  one, add a `fit_...` function and a line in `MODELS` in `ml/train_models.py` and rerun it.
* All 11 models use the same V15 dataset and the same 27 inputs; `wall_model.json` is the V15
  model, unchanged. `models/training_report.txt` has the side-by-side test results.

## What changed from V14 (in V15)
* **Features** - the "main-echo profile" (features._echo_profile). The strongest point between
  30 and 70 mm is the wall echo; the model looks at how the signal dies away 10-70 mm behind
  it, as a ratio to the echo. The old first-peak search sometimes locked onto leakage residue
  at 15-20 mm (56 of the 720 wall recordings), which scrambled every V14 feature.
* **One model, three classes** (No stud / Dry stud / Wet stud) instead of two models. There is
  no Damp class: the new data has no intermediate moisture level to learn it from.
* **"No wall" gate** - a wall at the standoffs returns >= 69 dB, open air ~53 dB. Below 62 dB
  the app says "No wall detected" instead of guessing.
* **Honest test** - leave-one-board-out: a board's dry AND wet sessions are both held out.
* CSV schema 7: the echo features are logged in data_log.csv (an existing schema-6
  data_log.csv is renamed to data_log_legacy_*.csv automatically, as before).

## Data used (ml_dataset.csv, 840 recordings, 2026-11-02 ... 11-09, all at the 50 mm standoffs)
| Folder | Recordings | Use |
|---|---|---|
| DryWall+Wood_Dry_S1..S10 | 100 | class "Dry stud" |
| DryWall+Wood_Wet_S1..S10 | 600 | class "Wet stud" (all 60 scans of each session) |
| DryWall | 20 | class "No stud" |
| Wood_Dry_S1..S10 | 100 | reference only (not a wall) |
| OpenAir-Standoff / -noStandoff | 20 | reference only; sets the "no wall" gate |
| S3,S4 Old wet scans | 0 | skipped (folder name contains "old") |

Cleaning done by build_dataset.py:
* every feature recomputed from the .h5 with its own background (CSV feature columns ignored);
* DryWall+Wood_Wet_S5: the CSV lists Wood_+_drywall_Dry_N.h5 for 56 rows but the files are
  named ..._Saturated_N.h5 - matched by trial number (meta_h5_renamed = 1);
* the 10 wood-alone S8 scans sit inside DryWall+Wood_Dry_S8 (Wood_Dry_S8 is empty) - they are
  recognised by their material column;
* labels reduced to one column, wall_class; never-inputs kept only as meta_*.

## Reading models/training_report.txt
* Session counts are the numbers to trust: scans inside one session are near-copies.
* "wet ranking" = chance that a wet session gets a higher wet probability than a dry one.

## Adding data later
Put the new Data Logging folders next to the old ones and rerun the two commands. Use a new
sample ID for every new board. To fix a label without editing a CSV, add a line to
ml/label_overrides.csv (columns: folder,h5_file,wetness,material,sample_id,exclude,note).
