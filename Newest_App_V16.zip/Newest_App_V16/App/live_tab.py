"""
live_tab.py

Live moisture dashboard. The MainWindow owns the global live acquisition
session and sends extracted features here. This tab no longer starts/stops
the sensor and contains no live graphs; it is the placeholder ML dashboard.
"""

from __future__ import annotations

import numpy as np
from PySide6.QtCore import QSettings, QSize, Qt
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import (
    QAbstractItemView, QComboBox, QGridLayout, QGroupBox, QHBoxLayout, QHeaderView, QLabel,
    QPushButton, QSizePolicy, QStackedWidget, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from features import echo_quality_check, extract_features
from moisture_model import MoisturePredictor

CLASS_COLORS = {"No stud": "#8b97a8", "Dry stud": "#7fd88f", "Wet stud": "#e56b6f"}
MODEL_SETTING = "live/model_file"


def wet_color(wet_pct: float) -> str:
    return "#e56b6f" if wet_pct >= 50.0 else ("#e5c85c" if wet_pct >= 30.0 else "#7fd88f")


ROLLING_WINDOW_SIZE = 10
PRINT_INTERVAL_MS = 100


def extract_features_from_window(amplitude_window, phase_window, distances_m, background_corrected=False,
                                 noise_level=None):
    """Thin wrapper. ALL feature math lives in features.py, which the Data Logging tab also
    uses, so live features and the rows written to data_log.csv are computed identically."""
    return extract_features(
        amplitude_window, phase_window, distances_m, background_corrected=background_corrected,
        noise_level=noise_level,
    )


def run_placeholder_model(features: dict) -> tuple[float, float]:
    """
    Placeholder only. Returns (moisture_percent, confidence_percent).

    Moisture is intentionally derived from a sensor amplitude feature so the
    dashboard visibly changes during testing. It is NOT a real moisture model.
    Confidence is based on signal stability and is also only a visual placeholder.
    """
    amplitude = float(features["peak_amplitude_mean"])
    variability = float(np.sqrt(max(float(features["frame_to_frame_variance"]), 0.0)))

    # Keep the existing amplitude-based placeholder behavior, but present it
    # as a continuous moisture percentage instead of a categorical label.
    moisture_pct = float(np.clip((amplitude / 6000.0) * 100.0, 0.0, 100.0))

    # Lower frame-to-frame variation gives the future model a visually intuitive
    # "more confident" placeholder. Clamp it so the display remains useful.
    relative_variability = variability / max(abs(amplitude), 1.0)
    confidence_pct = float(np.clip(100.0 - relative_variability * 250.0, 0.0, 100.0))

    return moisture_pct, confidence_pct


class CircularPercentage(QWidget):
    """Circular percentage indicator with a colored filled arc."""

    def __init__(self, title: str, neutral_color: str = "#5fb3e8"):
        super().__init__()
        self.title = title
        self.value = 0.0
        self.fill_color = neutral_color
        self.setMinimumSize(100, 100)
        self.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        self.setObjectName("circularPercentage")

    # Preferred size is the original 230 px; the widget shrinks to fit small displays.
    def sizeHint(self):
        return QSize(200, 200)

    def minimumSizeHint(self):
        return QSize(100, 100)

    def set_value(self, value: float, color: str | None = None):
        self.value = float(np.clip(value, 0.0, 100.0))
        if color is not None:
            self.fill_color = color
        self.update()

    def paintEvent(self, event):
        del event
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        side = min(self.width(), self.height())
        # Everything scales with the widget so the dial looks identical to the
        # original at 230 px and still fits on a 5-inch display when smaller.
        pen_w = max(7, round(side * 0.078))
        margin = pen_w
        rect = self.rect().adjusted(
            (self.width() - side) // 2 + margin,
            (self.height() - side) // 2 + margin,
            -(self.width() - side) // 2 - margin,
            -(self.height() - side) // 2 - margin,
        )

        track_pen = QPen(Qt.GlobalColor.black)
        track_pen.setWidth(pen_w)
        track_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(track_pen)
        painter.drawArc(rect, 90 * 16, -360 * 16)

        fill_pen = QPen(self.fill_color)
        fill_pen.setWidth(pen_w)
        fill_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(fill_pen)
        painter.drawArc(rect, 90 * 16, int(-360 * 16 * self.value / 100.0))

        painter.setPen(Qt.GlobalColor.white)
        value_font = painter.font()
        value_font.setPointSizeF(max(9.0, side * 0.117))
        value_font.setBold(True)
        painter.setFont(value_font)
        painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, f"{self.value:.1f}%")

        title_font = painter.font()
        title_font.setPointSizeF(max(7.0, side * 0.048))
        title_font.setBold(False)
        painter.setFont(title_font)
        painter.drawText(
            rect.adjusted(0, round(side * 0.21), 0, 0),
            Qt.AlignmentFlag.AlignCenter,
            self.title,
        )


class LiveTab(QWidget):
    """Dashboard fed by the global live scan in MainWindow."""

    def __init__(self, sensor_manager):
        super().__init__()
        self.mgr = sensor_manager
        self.predictor = MoisturePredictor()
        self._build_ui()

    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(8, 6, 8, 6)
        outer.setSpacing(6)

        # Plain label (no group box) saves vertical space on small displays.
        self.status_label = QLabel("Idle — use Start Measurement in the top-right corner.")
        self.status_label.setObjectName("summaryLabel")
        self.status_label.setWordWrap(True)
        outer.addWidget(self.status_label)

        title = ("Live Prediction" if self.predictor.available
                 else "Live Prediction — no trained model found in App/models (placeholder)")
        results_box = QGroupBox(title)
        results_layout = QVBoxLayout(results_box)
        results_layout.setContentsMargins(6, 6, 6, 6)
        results_layout.setSpacing(4)

        # --- model picker: every *.json in App/models is one entry ---
        picker = QHBoxLayout()
        picker.setSpacing(6)
        picker.addWidget(QLabel("Model"))
        self.model_combo = QComboBox()
        self.model_combo.setMinimumHeight(36)
        self.model_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        for m in self.predictor.models:
            self.model_combo.addItem(f"{m.name}   ({m.score} test sessions)" if m.score else m.name)
        picker.addWidget(self.model_combo, 1)
        self.compare_button = QPushButton("Compare all")
        self.compare_button.setCheckable(True)
        self.compare_button.setMinimumHeight(36)
        picker.addWidget(self.compare_button)
        results_layout.addLayout(picker)
        self.model_info = QLabel("")
        self.model_info.setObjectName("featureName")
        self.model_info.setWordWrap(True)
        results_layout.addWidget(self.model_info)
        if not self.predictor.available:
            self.model_combo.setEnabled(False)
            self.compare_button.setEnabled(False)

        # --- page 0: the selected model (label + two dials) ---
        single = QWidget()
        single_layout = QGridLayout(single)
        single_layout.setContentsMargins(0, 0, 0, 0)
        single_layout.setColumnStretch(0, 1)
        single_layout.setColumnStretch(1, 1)
        self.confidence_indicator = CircularPercentage("Confidence", "#5fb3e8")
        self.moisture_indicator = CircularPercentage(
            "Wet probability" if self.predictor.available else "Moisture Content", "#7fd88f")
        # No stud / Dry stud / Wet stud label above the two dials.
        self.class_label = QLabel("—")
        self.class_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        single_layout.addWidget(self.class_label, 0, 0, 1, 2)
        single_layout.addWidget(self.confidence_indicator, 1, 0, alignment=Qt.AlignmentFlag.AlignCenter)
        single_layout.addWidget(self.moisture_indicator, 1, 1, alignment=Qt.AlignmentFlag.AlignCenter)
        self._set_class_label(None)

        # --- page 1: every model on the same scan, side by side ---
        compare = QWidget()
        compare_layout = QVBoxLayout(compare)
        compare_layout.setContentsMargins(0, 0, 0, 0)
        compare_layout.setSpacing(2)
        self.compare_status = QLabel("Start a measurement to compare the models. Tap a row to select that model.")
        self.compare_status.setObjectName("featureName")
        self.compare_status.setWordWrap(True)
        compare_layout.addWidget(self.compare_status)
        self.compare_table = QTableWidget(len(self.predictor.models), 4)
        self.compare_table.setHorizontalHeaderLabels(["Model", "Answer", "Wet %", "Stud %"])
        self.compare_table.verticalHeader().setVisible(False)
        self.compare_table.verticalHeader().setDefaultSectionSize(30)
        self.compare_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.compare_table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.compare_table.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        header = self.compare_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for col in (1, 2, 3):
            header.setSectionResizeMode(col, QHeaderView.ResizeMode.ResizeToContents)
        for row, m in enumerate(self.predictor.models):
            self.compare_table.setItem(row, 0, QTableWidgetItem(m.name))
            for col in (1, 2, 3):
                item = QTableWidgetItem("—")
                item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                self.compare_table.setItem(row, col, item)
        self.compare_table.setMinimumHeight(220)
        compare_layout.addWidget(self.compare_table, 1)

        self.result_stack = QStackedWidget()
        self.result_stack.addWidget(single)
        self.result_stack.addWidget(compare)
        results_layout.addWidget(self.result_stack, 1)
        outer.addWidget(results_box, 1)

        # restore the model used last time, then connect the controls
        saved = QSettings("RadarMoistureTomography", "A121Console").value(MODEL_SETTING, "")
        if saved:
            self.predictor.select(str(saved))
        self.model_combo.setCurrentIndex(self.predictor.selected)
        self._show_model_info()
        self.model_combo.currentIndexChanged.connect(self._on_model_changed)
        self.compare_button.toggled.connect(self._on_compare_toggled)
        self.compare_table.cellClicked.connect(lambda row, _col: self.model_combo.setCurrentIndex(row))

        features_box = QGroupBox("Extracted Features")
        feat_grid = QGridLayout(features_box)
        feat_grid.setContentsMargins(6, 6, 6, 6)
        feat_grid.setSpacing(4)
        self.feature_labels = {}
        # The same primary features the Data Logging tab writes to data_log.csv.
        feature_names = [
            "echo_distance_m", "echo_amplitude_db", "e20_db",
            "e40_db", "e60_db", "e70_db",
            "front_distance_m", "rear_energy_ratio_db", "peaks_found",
        ]
        for i, name in enumerate(feature_names):
            row, col = divmod(i, 3)
            title = QLabel(name)
            title.setObjectName("featureName")
            value = QLabel("—")
            value.setObjectName("featureValue")
            cell = QVBoxLayout()
            cell.setContentsMargins(0, 0, 0, 0)
            cell.setSpacing(0)
            cell.addWidget(title)
            cell.addWidget(value)
            wrapper = QWidget()
            wrapper.setLayout(cell)
            feat_grid.addWidget(wrapper, row, col)
            self.feature_labels[name] = value
        outer.addWidget(features_box)

    # ---- model picker ----
    def _show_model_info(self):
        m = self.predictor.current
        if m is None:
            self.model_info.setText("")
            return
        test = f"  Test on unseen boards: {m.score} sessions correct" if m.score else ""
        wet = m.meta.get("wet_sessions_correct")
        dry = m.meta.get("dry_sessions_correct")
        if wet and dry:
            test += f" (wet {wet}, dry {dry})."
        self.model_info.setText(f"{m.description}{test}")
        # the selected model is marked with an arrow in the comparison table
        for row, model in enumerate(self.predictor.models):
            self.compare_table.item(row, 0).setText(("▶ " if row == self.predictor.selected else "") + model.name)

    def _on_model_changed(self, index: int):
        if index < 0:
            return
        self.predictor.select(int(index))
        if self.predictor.current is not None:
            QSettings("RadarMoistureTomography", "A121Console").setValue(MODEL_SETTING, self.predictor.current.file)
        self._show_model_info()
        self.confidence_indicator.set_value(0.0, "#5fb3e8")
        self.moisture_indicator.set_value(0.0, "#5fb3e8")
        self._set_class_label(None)

    def _on_compare_toggled(self, checked: bool):
        self.predictor.reset()
        self.result_stack.setCurrentIndex(1 if checked else 0)
        self.compare_button.setText("Show dials" if checked else "Compare all")

    def _clear_compare(self, message: str):
        self.compare_status.setText(message)
        for row in range(self.compare_table.rowCount()):
            for col in (1, 2, 3):
                item = self.compare_table.item(row, col)
                item.setText("—")
                item.setForeground(QColor("#6b7686"))

    def _fill_compare(self, results):
        votes = {}
        for row, (_model, res) in enumerate(results):
            cells = [self.compare_table.item(row, col) for col in (1, 2, 3)]
            if not res:
                for item in cells:
                    item.setText("—")
                continue
            votes[res["label"]] = votes.get(res["label"], 0) + 1
            wet = res["wet_probability"] * 100.0
            cells[0].setText(res["label"])
            cells[0].setForeground(QColor(CLASS_COLORS.get(res["label"], "#5fb3e8")))
            cells[1].setText(f"{wet:.0f}")
            cells[1].setForeground(QColor(wet_color(wet)))
            cells[2].setText(f"{res['stud_probability'] * 100.0:.0f}")
            cells[2].setForeground(QColor("#d7dde6"))
        order = sorted(votes.items(), key=lambda kv: -kv[1])
        self.compare_status.setText("Votes: " + ",  ".join(f"{k} {v}" for k, v in order)
                                    + "   (tap a row to select that model)")

    @staticmethod
    def moisture_color(moisture_pct: float) -> str:
        """Map the requested moisture ranges to visual colors."""
        if moisture_pct < 16.0:
            return "#5fb3e8"  # dry / below elevated-moisture range
        if moisture_pct < 20.0:
            return "#7fd88f"  # elevated / green
        if moisture_pct < 30.0:
            return "#e5c85c"  # increasingly wet / yellow
        return "#e56b6f"  # saturation and above / red

    @staticmethod
    def moisture_class(moisture_pct: float) -> str:
        """Same three classes as the Data Logging 'Moisture level' choices."""
        if moisture_pct < 16.0:
            return "Dry"
        if moisture_pct < 30.0:
            return "Damp"
        return "Saturated"

    def _set_class_label(self, moisture_pct):
        if moisture_pct is None:
            self.class_label.setText("—")
            self.class_label.setStyleSheet("color: #6b7686; font-size: 18px; font-weight: 700;")
        else:
            self.class_label.setText(self.moisture_class(moisture_pct))
            self.class_label.setStyleSheet(
                f"color: {self.moisture_color(moisture_pct)}; font-size: 18px; font-weight: 700;"
            )

    def update_features(self, features: dict):
        """Receive the latest feature set from the global live acquisition."""
        for name, label_widget in self.feature_labels.items():
            val = features.get(name)
            if val is None or (isinstance(val, (float, np.floating)) and np.isnan(val)):
                label_widget.setText("—")   # not computable (e.g. fewer than two peaks), never shown as 0
            else:
                label_widget.setText(f"{val:.4g}" if isinstance(val, (float, np.floating)) else str(val))

        if not self.predictor.available:
            moisture_pct, confidence_pct = run_placeholder_model(features)
            self.confidence_indicator.set_value(confidence_pct, "#5fb3e8")
            self.moisture_indicator.set_value(moisture_pct, self.moisture_color(moisture_pct))
            self._set_class_label(moisture_pct)
            return

        comparing = self.compare_button.isChecked()
        ok, reason = echo_quality_check(features)
        if not ok:
            self.predictor.reset()
            self.class_label.setText(reason)
            self.class_label.setStyleSheet("color: #e5c85c; font-size: 14px; font-weight: 600;")
            self.confidence_indicator.set_value(0.0, "#5fb3e8")
            self.moisture_indicator.set_value(0.0, "#5fb3e8")
            if comparing:
                self._clear_compare(reason)
            return
        if comparing:
            results = self.predictor.predict_all(features)
            self._fill_compare(results)
            result = results[self.predictor.selected][1]
        else:
            result = self.predictor.predict(features)
        if not result:
            return
        color = CLASS_COLORS.get(result["label"], "#5fb3e8")
        wet = result["wet_probability"] * 100.0
        self.class_label.setText(result["label"])
        self.class_label.setStyleSheet(f"color: {color}; font-size: 18px; font-weight: 700;")
        self.confidence_indicator.set_value(result["confidence"] * 100.0, "#5fb3e8")
        self.moisture_indicator.set_value(wet, wet_color(wet))

    def set_scanning(self, scanning: bool, message: str | None = None):
        if message:
            self.status_label.setText(message)
        else:
            self.status_label.setText("Scanning…" if scanning else "Idle — use Start Measurement in the top-right corner.")

    def reset_results(self):
        self.confidence_indicator.set_value(0.0, "#5fb3e8")
        self.moisture_indicator.set_value(0.0, "#5fb3e8")
        self._set_class_label(None)
        if self.predictor.available:
            self.predictor.reset()
            self._clear_compare("Start a measurement to compare the models. Tap a row to select that model.")
        for label in self.feature_labels.values():
            label.setText("—")
